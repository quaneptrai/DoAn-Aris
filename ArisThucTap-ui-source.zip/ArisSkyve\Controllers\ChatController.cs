using ArisSkyve.Domain.Entities;
using ArisSkyve.Hubs;
using ArisSkyve.Infrastructure.Data.Context;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Security.Claims;

namespace ArisSkyve.Controllers
{
    [Authorize]
    public class ChatController : Controller
    {
        private static readonly HashSet<string> AllowedImageTypes = new()
        { "image/jpeg", "image/png", "image/webp", "image/gif" };

        private readonly ArisDBContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpClientFactory _httpClientFactory;

        public ChatController(ArisDBContext context, IConfiguration config, IHttpClientFactory httpClientFactory)
        {
            _context = context;
            _config = config;
            _httpClientFactory = httpClientFactory;
        }

        private int CurrentUserId => int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

        public async Task<IActionResult> Index(int? userId)
        {
            var me = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == CurrentUserId);
            if (me == null) return RedirectToAction("Login", "Account");

            ViewBag.OpenUserId = userId;
            return View(me);
        }

        [HttpGet]
        public async Task<IActionResult> GetConversations()
        {
            var myId = CurrentUserId;

            var messages = await _context.Messages
                .Where(m => m.SenderId == myId || m.ReceiverId == myId)
                .Include(m => m.Sender).ThenInclude(u => u.Profile)
                .Include(m => m.Receiver).ThenInclude(u => u.Profile)
                .OrderByDescending(m => m.SentAt)
                .ToListAsync();

            var conversations = messages
                .GroupBy(m => m.SenderId == myId ? m.ReceiverId : m.SenderId)
                .Select(g =>
                {
                    var last = g.First();
                    var partner = last.SenderId == myId ? last.Receiver : last.Sender;
                    var lastMessagePreview = !string.IsNullOrWhiteSpace(last.Content)
                        ? last.Content
                        : (last.ImageUrl != null ? "Đã gửi một hình ảnh" : last.Content);
                    return new
                    {
                        userId = partner.Id,
                        username = partner.Username,
                        avatar = partner.Profile?.AvatarUrl ?? "/images/default-avatar.png",
                        lastMessage = lastMessagePreview,
                        lastMessageAt = last.SentAt,
                        isMine = last.SenderId == myId,
                        unreadCount = g.Count(m => m.ReceiverId == myId && !m.IsRead),
                        isOnline = partner.ShowActiveStatus && ChatHub.IsConnected(partner.Id)
                    };
                })
                .OrderByDescending(c => c.lastMessageAt)
                .ToList();

            return Json(conversations);
        }

        [HttpGet]
        public async Task<IActionResult> GetMessages(int userId)
        {
            var myId = CurrentUserId;

            var partner = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == userId);
            if (partner == null) return NotFound();

            var messages = await _context.Messages
                .Where(m => (m.SenderId == myId && m.ReceiverId == userId) || (m.SenderId == userId && m.ReceiverId == myId))
                .OrderBy(m => m.SentAt)
                .Select(m => new
                {
                    id = m.Id,
                    senderId = m.SenderId,
                    receiverId = m.ReceiverId,
                    content = m.Content,
                    imageUrl = m.ImageUrl,
                    isForwarded = m.IsForwarded,
                    sentAt = m.SentAt,
                    isRead = m.IsRead,
                    replyTo = m.ReplyToMessage == null ? null : new
                    {
                        id = m.ReplyToMessage.Id,
                        senderId = m.ReplyToMessage.SenderId,
                        senderUsername = m.ReplyToMessage.Sender.Username,
                        content = m.ReplyToMessage.Content,
                        imageUrl = m.ReplyToMessage.ImageUrl
                    }
                })
                .ToListAsync();

            return Json(new
            {
                partner = new
                {
                    id = partner.Id,
                    username = partner.Username,
                    avatar = partner.Profile?.AvatarUrl ?? "/images/default-avatar.png",
                    isOnline = partner.ShowActiveStatus && ChatHub.IsConnected(partner.Id)
                },
                messages
            });
        }

        [HttpGet]
        public async Task<IActionResult> SearchUsers(string q)
        {
            if (string.IsNullOrWhiteSpace(q)) return Json(Array.Empty<object>());

            var myId = CurrentUserId;

            var users = await _context.Users
                .Include(u => u.Profile)
                .Where(u => u.Id != myId && (u.Username.Contains(q) || (u.Profile != null && u.Profile.FullName.Contains(q))))
                .Take(10)
                .ToListAsync();

            var userIds = users.Select(u => u.Id).ToList();
            var friendships = await _context.Friendships
                .Where(f => (f.RequesterId == myId && userIds.Contains(f.AddresseeId))
                         || (f.AddresseeId == myId && userIds.Contains(f.RequesterId)))
                .ToListAsync();

            var result = users.Select(u =>
            {
                var rel = friendships.FirstOrDefault(f => f.RequesterId == u.Id || f.AddresseeId == u.Id);
                string friendStatus = "none";
                int? friendshipId = null;
                if (rel != null)
                {
                    friendshipId = rel.Id;
                    friendStatus = rel.Status == FriendshipStatus.Accepted
                        ? "friends"
                        : rel.RequesterId == myId ? "pending_sent" : "pending_received";
                }

                return new
                {
                    id = u.Id,
                    username = u.Username,
                    avatar = (u.Profile != null ? u.Profile.AvatarUrl : null) ?? "/images/default-avatar.png",
                    friendStatus,
                    friendshipId
                };
            }).ToList();

            return Json(result);
        }

        // Uploads a chat image to the AiCore media store (same remote storage Dashboard's
        // post images use) and hands back its URL; the client then sends that URL through
        // ChatHub.SendMessage separately, matching the app's existing upload-then-reference
        // pattern for user-generated media.
        [HttpPost]
        public async Task<IActionResult> UploadChatImage(IFormFile? file)
        {
            if (file == null || file.Length == 0)
                return Json(new { success = false, message = "Vui lòng chọn ảnh." });

            if (!AllowedImageTypes.Contains(file.ContentType))
                return Json(new { success = false, message = "Chỉ hỗ trợ ảnh JPEG, PNG, WEBP hoặc GIF." });

            var aiCoreBaseUrl = _config["AiCore:BaseUrl"];
            var client = _httpClientFactory.CreateClient();

            try
            {
                using var content = new MultipartFormDataContent();
                using var stream = file.OpenReadStream();
                var streamContent = new StreamContent(stream);
                streamContent.Headers.ContentType = new MediaTypeHeaderValue(file.ContentType);
                content.Add(streamContent, "file", file.FileName);

                var response = await client.PostAsync($"{aiCoreBaseUrl}/upload-image", content);
                if (!response.IsSuccessStatusCode)
                    return Json(new { success = false, message = "Không thể tải ảnh lên." });

                var result = await response.Content.ReadFromJsonAsync<AiCoreUploadResult>();
                if (result?.Url == null)
                    return Json(new { success = false, message = "Không thể tải ảnh lên." });

                return Json(new { success = true, url = result.Url });
            }
            catch (Exception)
            {
                return Json(new { success = false, message = "Lỗi kết nối tới dịch vụ lưu trữ." });
            }
        }

        private class AiCoreUploadResult
        {
            public string? Message { get; set; }
            public string? Filename { get; set; }
            public string? Url { get; set; }
        }
    }
}
