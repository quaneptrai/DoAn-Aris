using ArisSkyve.Application.DTOs;
using ArisSkyve.Domain.Entities;
using ArisSkyve.Infrastructure.Data.Context;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Text.Json;

namespace ArisSkyve.Controllers
{
    [Authorize]
    public class JobApplicationsController : Controller
    {
        private readonly ArisDBContext _context;

        public JobApplicationsController(ArisDBContext context)
        {
            _context = context;
        }

        private int CurrentUserId => int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

        private static List<string> ParseJsonList(string? json)
        {
            if (string.IsNullOrWhiteSpace(json) || json == "[]") return new List<string>();
            try
            {
                return JsonSerializer.Deserialize<List<string>>(json) ?? new List<string>();
            }
            catch (JsonException)
            {
                return new List<string>();
            }
        }

        private static string StatusLabel(string status) => status switch
        {
            JobApplicationStatus.Submitted => "Đã nộp",
            JobApplicationStatus.UnderReview => "Đang xem xét",
            JobApplicationStatus.Shortlisted => "Vào danh sách rút gọn",
            JobApplicationStatus.InterviewScheduled => "Mời phỏng vấn",
            JobApplicationStatus.Offered => "Nhận offer",
            JobApplicationStatus.Rejected => "Từ chối",
            JobApplicationStatus.Withdrawn => "Đã rút đơn",
            _ => status
        };

        // Dữ liệu để render form ứng tuyển: CV của ứng viên, câu hỏi sàng lọc của job (nếu
        // có), và đơn đã nộp trước đó (nếu có) để UI hiện đúng trạng thái thay vì để ứng
        // viên nộp trùng.
        [HttpGet]
        public async Task<IActionResult> GetApplyModal(int jobId)
        {
            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == CurrentUserId);
            if (user?.Profile == null)
                return Json(new { success = false, message = "Vui lòng hoàn thiện hồ sơ trước khi ứng tuyển." });

            var job = await _context.JobPostings.FirstOrDefaultAsync(j => j.Id == jobId);
            if (job == null) return NotFound();

            if (user.Role == "Business")
            {
                return Json(new { success = false, isBusiness = true, isOwnJob = job.BusinessAccountId == user.Profile.Id });
            }

            var resumes = await _context.Resumes
                .Where(r => r.EmployeeId == user.Profile.Id)
                .OrderByDescending(r => r.LastUpdatedAt)
                .Select(r => new { id = r.Id, name = r.Label, fileUrl = r.FileUrl })
                .ToListAsync();

            var existingApplications = await _context.JobApplications
                .Where(a => a.JobPostingId == jobId && a.ApplicantId == user.Profile.Id && a.Status != JobApplicationStatus.Withdrawn)
                .OrderByDescending(a => a.AppliedAt)
                .ToListAsync();
            var existing = existingApplications.FirstOrDefault();

            return Json(new
            {
                success = true,
                isBusiness = false,
                jobActive = job.isActive,
                resumes,
                screeningQuestions = ParseJsonList(job.ScreeningQuestions),
                alreadyApplied = existing != null,
                applicationCount = existingApplications.Count,
                application = existing == null ? null : new { id = existing.Id, status = existing.Status, appliedAt = existing.AppliedAt }
            });
        }

        [HttpPost]
        public async Task<IActionResult> Apply(int jobId, [FromBody] SubmitJobApplicationDto dto)
        {
            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == CurrentUserId);
            if (user?.Profile == null)
                return Json(new { success = false, message = "Vui lòng hoàn thiện hồ sơ trước khi ứng tuyển." });

            if (user.Role == "Business")
                return Json(new { success = false, message = "Tài khoản doanh nghiệp không thể ứng tuyển vào tin tuyển dụng." });

            var job = await _context.JobPostings.FirstOrDefaultAsync(j => j.Id == jobId);
            if (job == null) return NotFound();

            if (!job.isActive)
                return Json(new { success = false, message = "Tin tuyển dụng này đã hết hạn hoặc ngừng nhận hồ sơ." });

            if (job.BusinessAccountId == user.Profile.Id)
                return Json(new { success = false, message = "Bạn không thể ứng tuyển vào tin của chính công ty mình." });

            // Candidates are allowed to apply more than once — the client-side flow (Jobs/
            // Details.cshtml) warns them re-applying can look unprofessional to the employer
            // and requires an explicit confirmation before hitting this endpoint again, but
            // it's never hard-blocked here. The employer's applicant list flags candidates
            // who show up more than once (see GetApplicantsForJob's applicationCount).
            var resume = dto == null ? null : await _context.Resumes.FirstOrDefaultAsync(r => r.Id == dto.ResumeId && r.EmployeeId == user.Profile.Id);
            if (resume == null)
                return Json(new { success = false, message = "Vui lòng chọn một CV hợp lệ." });

            var application = new JobApplication
            {
                JobPostingId = jobId,
                ApplicantId = user.Profile.Id,
                ResumeId = resume.Id,
                ResumeSnapshotUrl = resume.FileUrl,
                ResumeSnapshotName = string.IsNullOrWhiteSpace(resume.Label) ? user.Profile.FullName : resume.Label,
                FullName = user.Profile.FullName,
                Email = string.IsNullOrWhiteSpace(resume.Email) ? user.Email : resume.Email,
                CoverLetter = dto!.CoverLetter,
                ScreeningAnswers = JsonSerializer.Serialize(dto.ScreeningAnswers ?? new List<string>()),
                Status = JobApplicationStatus.Submitted,
                AppliedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            _context.JobApplications.Add(application);

            if (job.BusinessAccountId != null)
            {
                var businessProfile = await _context.Profiles.FirstOrDefaultAsync(p => p.Id == job.BusinessAccountId);
                if (businessProfile != null)
                {
                    _context.Notifications.Add(new Notification
                    {
                        UserId = businessProfile.UserId,
                        ActorId = user.Id,
                        Type = "JobApplication",
                        Content = $"{user.Profile.FullName} vừa ứng tuyển vào vị trí \"{job.Title}\".",
                        Link = $"/Jobs/Index?manageJobId={job.Id}",
                        CreatedAt = DateTime.UtcNow
                    });
                }
            }

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                return Json(new { success = false, message = "Không thể nộp đơn lúc này, vui lòng thử lại." });
            }

            return Json(new { success = true, applicationId = application.Id });
        }

        [HttpPost]
        public async Task<IActionResult> Withdraw(int applicationId)
        {
            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == CurrentUserId);
            if (user?.Profile == null) return NotFound();

            var application = await _context.JobApplications
                .FirstOrDefaultAsync(a => a.Id == applicationId && a.ApplicantId == user.Profile.Id);
            if (application == null) return NotFound();

            if (application.Status is JobApplicationStatus.Offered or JobApplicationStatus.Rejected or JobApplicationStatus.Withdrawn)
                return Json(new { success = false, message = "Không thể rút đơn ở trạng thái hiện tại." });

            application.Status = JobApplicationStatus.Withdrawn;
            application.UpdatedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync();

            return Json(new { success = true });
        }

        [HttpGet]
        public async Task<IActionResult> MyApplications()
        {
            bool isAjax = Request.Headers["X-Requested-With"] == "XMLHttpRequest";

            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == CurrentUserId);
            if (user?.Profile == null)
            {
                var empty = new MyApplicationsViewModel();
                return isAjax ? PartialView("_MyApplicationsPartial", empty) : View(empty);
            }

            var applications = await _context.JobApplications
                .Include(a => a.JobPosting).ThenInclude(j => j.BusinessAccount)
                .Where(a => a.ApplicantId == user.Profile.Id)
                .OrderByDescending(a => a.AppliedAt)
                .Select(a => new MyApplicationItemViewModel
                {
                    Id = a.Id,
                    JobId = a.JobPostingId,
                    JobTitle = a.JobPosting.Title,
                    CompanyName = a.JobPosting.BusinessAccount != null ? a.JobPosting.BusinessAccount.CompanyName : a.JobPosting.Company,
                    CompanyLogo = a.JobPosting.BusinessAccount != null ? a.JobPosting.BusinessAccount.AvatarUrl : null,
                    Salary = a.JobPosting.Salary,
                    Status = a.Status,
                    StatusNote = a.StatusNote,
                    AppliedAt = a.AppliedAt,
                    CanWithdraw = a.Status != JobApplicationStatus.Offered && a.Status != JobApplicationStatus.Rejected && a.Status != JobApplicationStatus.Withdrawn,
                    InterviewAt = a.InterviewAt,
                    InterviewLocation = a.InterviewLocation,
                    IsVideoCall = a.IsVideoCall
                })
                .ToListAsync();

            var model = new MyApplicationsViewModel { Applications = applications };
            return isAjax ? PartialView("_MyApplicationsPartial", model) : View(model);
        }

        // Danh sách ứng viên cho một job cụ thể — chỉ chủ sở hữu (BusinessAccount đã đăng
        // tin) mới được xem, dùng để đổ dữ liệu vào modal "Quản lý ứng viên".
        [HttpGet]
        public async Task<IActionResult> GetApplicantsForJob(int jobId, string? status = null)
        {
            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == CurrentUserId);
            if (user?.Profile == null || user.Role != "Business")
                return Json(new { success = false, message = "Chỉ tài khoản doanh nghiệp mới có thể xem danh sách ứng viên." });

            var job = await _context.JobPostings.FirstOrDefaultAsync(j => j.Id == jobId);
            if (job == null) return NotFound();
            if (job.BusinessAccountId != user.Profile.Id)
                return Json(new { success = false, message = "Bạn không có quyền xem tin tuyển dụng này." });

            var query = _context.JobApplications
                .Include(a => a.Applicant)
                .Where(a => a.JobPostingId == jobId && a.Status != JobApplicationStatus.Withdrawn);

            if (!string.IsNullOrWhiteSpace(status) && JobApplicationStatus.All.Contains(status))
                query = query.Where(a => a.Status == status);

            var raw = await query
                .OrderByDescending(a => a.AppliedAt)
                .Select(a => new
                {
                    a.Id,
                    a.ApplicantId,
                    a.FullName,
                    a.Email,
                    Avatar = a.Applicant.AvatarUrl,
                    ApplicantTitle = a.Applicant.JobTitle,
                    a.CoverLetter,
                    a.ResumeSnapshotUrl,
                    a.ResumeSnapshotName,
                    a.ScreeningAnswers,
                    a.Status,
                    a.StatusNote,
                    a.AppliedAt,
                    a.InterviewAt,
                    a.InterviewLocation,
                    a.IsVideoCall,
                    a.InterviewResponse
                })
                .ToListAsync();

            // Counted against ALL of this job's non-withdrawn applications (not just the
            // current status-filtered `raw`), so a candidate who applied under two different
            // statuses still gets flagged as having applied more than once.
            var applicationCounts = await _context.JobApplications
                .Where(a => a.JobPostingId == jobId && a.Status != JobApplicationStatus.Withdrawn)
                .GroupBy(a => a.ApplicantId)
                .Select(g => new { ApplicantId = g.Key, Count = g.Count() })
                .ToDictionaryAsync(x => x.ApplicantId, x => x.Count);

            var applicants = raw.Select(a => new
            {
                id = a.Id,
                fullName = a.FullName,
                email = a.Email,
                avatar = a.Avatar,
                jobTitle = a.ApplicantTitle,
                coverLetter = a.CoverLetter,
                resumeUrl = a.ResumeSnapshotUrl,
                resumeName = a.ResumeSnapshotName,
                screeningAnswers = ParseJsonList(a.ScreeningAnswers),
                status = a.Status,
                statusLabel = StatusLabel(a.Status),
                statusNote = a.StatusNote,
                appliedAt = a.AppliedAt,
                applicationCount = applicationCounts.GetValueOrDefault(a.ApplicantId, 1),
                interviewAt = a.InterviewAt,
                interviewLocation = a.InterviewLocation,
                isVideoCall = a.IsVideoCall,
                interviewResponse = a.InterviewResponse
            }).ToList();

            return Json(new { success = true, jobTitle = job.Title, applicants });
        }

        [HttpPost]
        public async Task<IActionResult> UpdateApplicationStatus(int applicationId, [FromBody] UpdateApplicationStatusDto dto)
        {
            if (dto == null || !JobApplicationStatus.All.Contains(dto.Status) || dto.Status == JobApplicationStatus.Withdrawn)
                return Json(new { success = false, message = "Trạng thái không hợp lệ." });

            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == CurrentUserId);
            if (user?.Profile == null || user.Role != "Business")
                return Json(new { success = false, message = "Chỉ tài khoản doanh nghiệp mới có thể cập nhật trạng thái." });

            var application = await _context.JobApplications
                .Include(a => a.JobPosting)
                .Include(a => a.Applicant)
                .FirstOrDefaultAsync(a => a.Id == applicationId);
            if (application == null) return NotFound();

            if (application.JobPosting.BusinessAccountId != user.Profile.Id)
                return Json(new { success = false, message = "Bạn không có quyền thao tác trên đơn ứng tuyển này." });

            if (application.Status == JobApplicationStatus.Withdrawn)
                return Json(new { success = false, message = "Ứng viên đã rút đơn ứng tuyển này." });

            application.Status = dto.Status;
            application.StatusNote = dto.Note;
            application.UpdatedAt = DateTime.UtcNow;

            _context.Notifications.Add(new Notification
            {
                UserId = application.Applicant.UserId,
                ActorId = CurrentUserId,
                Type = "ApplicationStatus",
                Content = $"Đơn ứng tuyển \"{application.JobPosting.Title}\" của bạn đã chuyển sang trạng thái: {StatusLabel(dto.Status)}.",
                Link = "/JobApplications/MyApplications",
                CreatedAt = DateTime.UtcNow
            });

            await _context.SaveChangesAsync();

            return Json(new { success = true, statusLabel = StatusLabel(dto.Status) });
        }

        // Schedules (or reschedules) an interview for an application: sets the status to
        // InterviewScheduled and stores the structured date/location alongside a free-text
        // note (reusing StatusNote, which already doubles as "note attached to the current
        // status" for the candidate-facing MyApplications view).
        [HttpPost]
        public async Task<IActionResult> ScheduleInterview(int applicationId, [FromBody] ScheduleInterviewDto dto)
        {
            if (dto == null || dto.ScheduledAt == default)
                return Json(new { success = false, message = "Vui lòng chọn thời gian phỏng vấn." });

            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == CurrentUserId);
            if (user?.Profile == null || user.Role != "Business")
                return Json(new { success = false, message = "Chỉ tài khoản doanh nghiệp mới có thể lên lịch phỏng vấn." });

            var application = await _context.JobApplications
                .Include(a => a.JobPosting)
                .Include(a => a.Applicant)
                .FirstOrDefaultAsync(a => a.Id == applicationId);
            if (application == null) return NotFound();

            if (application.JobPosting.BusinessAccountId != user.Profile.Id)
                return Json(new { success = false, message = "Bạn không có quyền thao tác trên đơn ứng tuyển này." });

            if (application.Status is JobApplicationStatus.Withdrawn or JobApplicationStatus.Rejected or JobApplicationStatus.Offered)
                return Json(new { success = false, message = "Không thể lên lịch phỏng vấn ở trạng thái hiện tại." });

            var isReschedule = application.Status == JobApplicationStatus.InterviewScheduled;

            application.Status = JobApplicationStatus.InterviewScheduled;
            application.InterviewAt = dto.ScheduledAt;
            application.IsVideoCall = dto.IsVideoCall;
            application.InterviewLocation = dto.IsVideoCall ? null : dto.Location;
            application.StatusNote = dto.Note;
            application.InterviewResponse = "Pending";
            application.UpdatedAt = DateTime.UtcNow;

            _context.Notifications.Add(new Notification
            {
                UserId = application.Applicant.UserId,
                ActorId = CurrentUserId,
                Type = "InterviewScheduled",
                Content = isReschedule
                    ? $"Lịch phỏng vấn cho \"{application.JobPosting.Title}\" đã được đổi sang {dto.ScheduledAt:dd/MM/yyyy HH:mm}."
                    : $"Bạn được mời phỏng vấn cho \"{application.JobPosting.Title}\" vào lúc {dto.ScheduledAt:dd/MM/yyyy HH:mm}.",
                Link = "/Chat/Index?networkTab=requests",
                CreatedAt = DateTime.UtcNow
            });

            await _context.SaveChangesAsync();

            return Json(new
            {
                success = true,
                statusLabel = StatusLabel(application.Status),
                interviewAt = application.InterviewAt,
                interviewLocation = application.InterviewLocation,
                isVideoCall = application.IsVideoCall
            });
        }

        // Candidate-facing "Lời mời" (Invitations) list — every application of theirs
        // currently sitting at InterviewScheduled, most recent interview first. Kept
        // separate from MyApplications since these need an explicit accept/decline rather
        // than being just another passive status row.
        [HttpGet]
        public async Task<IActionResult> GetInterviewInvitations()
        {
            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == CurrentUserId);
            if (user?.Profile == null) return Json(new { success = true, invitations = Array.Empty<object>() });

            var invitations = await _context.JobApplications
                .Include(a => a.JobPosting).ThenInclude(j => j.BusinessAccount)
                .Where(a => a.ApplicantId == user.Profile.Id && a.Status == JobApplicationStatus.InterviewScheduled)
                .OrderByDescending(a => a.InterviewAt)
                .Select(a => new
                {
                    id = a.Id,
                    jobTitle = a.JobPosting.Title,
                    companyName = a.JobPosting.BusinessAccount != null ? a.JobPosting.BusinessAccount.CompanyName : a.JobPosting.Company,
                    companyLogo = a.JobPosting.BusinessAccount != null ? a.JobPosting.BusinessAccount.AvatarUrl : null,
                    interviewAt = a.InterviewAt,
                    interviewLocation = a.InterviewLocation,
                    isVideoCall = a.IsVideoCall,
                    note = a.StatusNote,
                    response = a.InterviewResponse
                })
                .ToListAsync();

            return Json(new { success = true, invitations });
        }

        // Candidate accepts or declines a scheduled interview. Doesn't change the
        // application's overall Status (stays InterviewScheduled either way) — Declined
        // just tells the employer this time doesn't work, so they know to reschedule.
        [HttpPost]
        public async Task<IActionResult> RespondToInterview(int applicationId, bool accept)
        {
            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == CurrentUserId);
            if (user?.Profile == null) return NotFound();

            var application = await _context.JobApplications
                .Include(a => a.JobPosting).ThenInclude(j => j.BusinessAccount)
                .FirstOrDefaultAsync(a => a.Id == applicationId && a.ApplicantId == user.Profile.Id);
            if (application == null) return NotFound();

            if (application.Status != JobApplicationStatus.InterviewScheduled)
                return Json(new { success = false, message = "Lời mời phỏng vấn này không còn hiệu lực." });

            application.InterviewResponse = accept ? "Accepted" : "Declined";
            application.UpdatedAt = DateTime.UtcNow;

            var employerUserId = application.JobPosting.BusinessAccount?.UserId;
            if (employerUserId.HasValue)
            {
                _context.Notifications.Add(new Notification
                {
                    UserId = employerUserId.Value,
                    ActorId = CurrentUserId,
                    Type = "InterviewResponse",
                    Content = accept
                        ? $"{user.Profile.FullName} đã xác nhận tham gia phỏng vấn cho \"{application.JobPosting.Title}\"."
                        : $"{user.Profile.FullName} đã từ chối lịch phỏng vấn cho \"{application.JobPosting.Title}\".",
                    Link = $"/Jobs/Index?manageJobId={application.JobPostingId}",
                    CreatedAt = DateTime.UtcNow
                });
            }

            await _context.SaveChangesAsync();

            return Json(new { success = true, response = application.InterviewResponse });
        }
    }
}
