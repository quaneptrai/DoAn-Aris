using ArisSkyve.Application.DTOs;
using ArisSkyve.Domain.Entities;
using ArisSkyve.Hubs;
using ArisSkyve.Infrastructure.Data.Context;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace ArisSkyve.Controllers
{
    [Authorize]
    public class SettingsController : Controller
    {
        private static readonly string[] AllowedAvatarExtensions = { ".jpg", ".jpeg", ".png", ".webp", ".gif" };
        private const long MaxAvatarBytes = 5 * 1024 * 1024;

        private readonly ArisDBContext _context;
        private readonly IHubContext<ChatHub> _hub;
        private readonly IWebHostEnvironment _env;

        public SettingsController(ArisDBContext context, IHubContext<ChatHub> hub, IWebHostEnvironment env)
        {
            _context = context;
            _hub = hub;
            _env = env;
        }

        private int CurrentUserId => int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

        public async Task<IActionResult> Index()
        {
            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == CurrentUserId);
            if (user == null) return RedirectToAction("Login", "Account");

            return View(user);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateActiveStatus(bool enabled)
        {
            var userId = CurrentUserId;
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Id == userId);
            if (user == null) return NotFound();

            user.ShowActiveStatus = enabled;
            await _context.SaveChangesAsync();

            var isConnected = ChatHub.IsConnected(userId);
            await _hub.Clients.All.SendAsync("PresenceChanged", userId, enabled && isConnected);

            return Json(new { success = true });
        }

        [HttpPost]
        public async Task<IActionResult> UpdateUsername(string username)
        {
            username = (username ?? "").Trim();
            if (string.IsNullOrEmpty(username) || username.Length > 50)
                return Json(new { success = false, message = "Display name must be between 1 and 50 characters." });

            var userId = CurrentUserId;
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Id == userId);
            if (user == null) return NotFound();

            user.Username = username;
            await _context.SaveChangesAsync();

            // Refresh the auth cookie so the new name takes effect immediately, without a re-login.
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(ClaimTypes.Name, user.Username)
            };
            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(identity),
                new AuthenticationProperties { IsPersistent = true, ExpiresUtc = DateTime.UtcNow.AddDays(7) });

            return Json(new { success = true, username = user.Username });
        }

        [HttpPost]
        public async Task<IActionResult> UpdateAvatar(IFormFile avatar)
        {
            if (avatar == null || avatar.Length == 0)
                return Json(new { success = false, message = "Please choose an image." });

            var ext = Path.GetExtension(avatar.FileName).ToLowerInvariant();
            if (!AllowedAvatarExtensions.Contains(ext))
                return Json(new { success = false, message = "Unsupported image format." });

            if (avatar.Length > MaxAvatarBytes)
                return Json(new { success = false, message = "Image must be under 5MB." });

            var userId = CurrentUserId;
            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == userId);
            if (user == null) return NotFound();

            if (user.Profile == null)
            {
                user.Profile = new EmployesAccount
                {
                    UserId = user.Id,
                    FullName = user.Username,
                    Location = "Chưa cập nhật"
                };
                _context.Profiles.Add(user.Profile);
            }

            var fileName = $"{Guid.NewGuid()}{ext}";
            var avatarsDir = Path.Combine(_env.WebRootPath, "uploads", "avatars");
            Directory.CreateDirectory(avatarsDir);

            using (var stream = new FileStream(Path.Combine(avatarsDir, fileName), FileMode.Create))
            {
                await avatar.CopyToAsync(stream);
            }

            user.Profile.AvatarUrl = $"/uploads/avatars/{fileName}";
            await _context.SaveChangesAsync();

            return Json(new { success = true, avatarUrl = user.Profile.AvatarUrl });
        }

        // Same validation/storage pattern as UpdateAvatar, for the wide banner image shown
        // atop a company's profile page (BussinessAccount.CoverPhotoUrl, inherited from the
        // generic EmployesAccount field — nothing wired this up to an upload before now).
        [HttpPost]
        public async Task<IActionResult> UpdateCoverPhoto(IFormFile cover)
        {
            if (cover == null || cover.Length == 0)
                return Json(new { success = false, message = "Please choose an image." });

            var ext = Path.GetExtension(cover.FileName).ToLowerInvariant();
            if (!AllowedAvatarExtensions.Contains(ext))
                return Json(new { success = false, message = "Unsupported image format." });

            if (cover.Length > MaxAvatarBytes)
                return Json(new { success = false, message = "Image must be under 5MB." });

            var userId = CurrentUserId;
            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == userId);
            if (user?.Profile == null) return NotFound();

            var fileName = $"{Guid.NewGuid()}{ext}";
            var coversDir = Path.Combine(_env.WebRootPath, "uploads", "covers");
            Directory.CreateDirectory(coversDir);

            using (var stream = new FileStream(Path.Combine(coversDir, fileName), FileMode.Create))
            {
                await cover.CopyToAsync(stream);
            }

            user.Profile.CoverPhotoUrl = $"/uploads/covers/{fileName}";
            await _context.SaveChangesAsync();

            return Json(new { success = true, coverUrl = user.Profile.CoverPhotoUrl });
        }

        private static readonly string[] DefaultRejectionTemplates =
        {
            "Cảm ơn bạn đã dành thời gian ứng tuyển. Hồ sơ của bạn rất ấn tượng, tuy nhiên chưa thực sự phù hợp với yêu cầu của vị trí này ở thời điểm hiện tại.",
            "Vị trí này yêu cầu số năm kinh nghiệm nhiều hơn so với hồ sơ hiện tại của bạn. Rất mong được gặp lại bạn ở những vị trí phù hợp hơn trong tương lai.",
            "Chúng tôi đã tìm được ứng viên phù hợp hơn cho vị trí này. Cảm ơn bạn đã quan tâm đến công ty."
        };

        [HttpGet]
        public async Task<IActionResult> GetRejectionTemplates()
        {
            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == CurrentUserId);
            if (user?.Profile is not BussinessAccount business)
                return Json(new { success = false, message = "Chỉ tài khoản doanh nghiệp mới có mẫu từ chối." });

            List<string> templates = new();
            if (!string.IsNullOrWhiteSpace(business.RejectionTemplates))
            {
                try
                {
                    templates = System.Text.Json.JsonSerializer.Deserialize<List<string>>(business.RejectionTemplates) ?? new List<string>();
                }
                catch (System.Text.Json.JsonException)
                {
                    templates = new List<string>();
                }
            }

            if (templates.Count == 0) templates = DefaultRejectionTemplates.ToList();

            return Json(new { success = true, templates });
        }

        [HttpPost]
        public async Task<IActionResult> UpdateRejectionTemplates([FromBody] UpdateRejectionTemplatesDto dto)
        {
            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == CurrentUserId);
            if (user?.Profile is not BussinessAccount business)
                return Json(new { success = false, message = "Chỉ tài khoản doanh nghiệp mới có mẫu từ chối." });

            var templates = (dto?.Templates ?? new List<string>())
                .Select(t => t.Trim())
                .Where(t => !string.IsNullOrWhiteSpace(t))
                .ToList();

            business.RejectionTemplates = System.Text.Json.JsonSerializer.Serialize(templates);
            await _context.SaveChangesAsync();

            return Json(new { success = true, templates });
        }
    }
}
