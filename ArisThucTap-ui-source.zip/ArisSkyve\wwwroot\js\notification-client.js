// Wires up a notification bell dropdown: fetches the list, tracks unread count,
// marks read on click, and updates live over the same /hubs/chat connection
// ArisChat already maintains (see chat-client.js).
window.ArisNotifications = (function () {
    let stylesInjected = false;
    function injectStyles() {
        if (stylesInjected) return;
        stylesInjected = true;
        const style = document.createElement('style');
        style.id = 'aris-notification-styles';
        style.textContent = `
            .aris-notif-badge {
                position: absolute;
                top: 2px;
                right: 10px;
                background: #ef4444;
                color: #fff;
                font-size: 10px;
                font-weight: 700;
                min-width: 16px;
                height: 16px;
                border-radius: 999px;
                align-items: center;
                justify-content: center;
                border: 2px solid #0e1730;
                display: none;
                padding: 0 3px;
            }
            .aris-notif-dropdown {
                width: 320px;
                max-height: 420px;
                overflow-y: auto;
                padding: 0;
            }
            .aris-notif-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 12px 16px;
                font-weight: 700;
                font-size: 14px;
                border-bottom: 1px solid var(--cosmos-hairline, #29364b);
                list-style: none;
            }
            .aris-notif-markall {
                background: transparent;
                border: none;
                color: var(--cosmos-cyan, #7ec8f5);
                font-size: 12px;
                font-weight: 600;
            }
            .aris-notif-markall:hover { text-decoration: underline; }
            .aris-notif-empty {
                padding: 24px 16px;
                text-align: center;
                color: var(--cosmos-text-muted, #9bacc6);
                font-size: 13px;
                list-style: none;
            }
            .aris-notif-item {
                display: flex;
                align-items: flex-start;
                gap: 10px;
                padding: 10px 16px;
                text-decoration: none;
                color: inherit;
            }
            .aris-notif-item:hover { background: rgba(96,165,250,.10); }
            .aris-notif-item.unread { background: rgba(47,111,237,.18); }
            .aris-notif-item img {
                width: 36px;
                height: 36px;
                border-radius: 50%;
                object-fit: cover;
                flex-shrink: 0;
            }
            .aris-notif-item-body { min-width: 0; }
            .aris-notif-item-text {
                font-size: 13px;
                color: var(--cosmos-text, #edf2fa);
                white-space: normal;
                line-height: 1.35;
            }
            .aris-notif-item-time {
                font-size: 11px;
                color: var(--cosmos-text-muted, #9bacc6);
                margin-top: 2px;
            }
        `;
        document.head.appendChild(style);
    }

    function timeAgo(iso) {
        const seconds = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
        if (seconds < 60) return "just now";
        const minutes = Math.floor(seconds / 60);
        if (minutes < 60) return `${minutes}m ago`;
        const hours = Math.floor(minutes / 60);
        if (hours < 24) return `${hours}h ago`;
        const days = Math.floor(hours / 24);
        return `${days}d ago`;
    }

    function escapeHtml(str) {
        const div = document.createElement("div");
        div.innerText = str == null ? "" : str;
        return div.innerHTML;
    }

    function init({ bellBtn, badge, list }) {
        injectStyles();
        let notifications = [];
        let loaded = false;

        function updateBadge() {
            const count = notifications.filter(n => !n.isRead).length;
            if (count > 0) {
                badge.style.display = "flex";
                badge.textContent = count > 99 ? "99+" : count;
            } else {
                badge.style.display = "none";
            }
        }

        function renderList() {
            if (notifications.length === 0) {
                list.innerHTML = '<li class="aris-notif-empty">No notifications yet.</li>';
                return;
            }
            const header = `
                <li class="aris-notif-header">
                    <span>Notifications</span>
                    <button type="button" class="aris-notif-markall">Mark all as read</button>
                </li>`;
            const items = notifications.map(n => `
                <li>
                    <a href="${n.link || '#'}" class="aris-notif-item ${n.isRead ? '' : 'unread'}" data-id="${n.id}">
                        <img src="${n.actorAvatar || '/images/default-avatar.png'}">
                        <div class="aris-notif-item-body">
                            <div class="aris-notif-item-text">${escapeHtml(n.content)}</div>
                            <div class="aris-notif-item-time">${timeAgo(n.createdAt)}</div>
                        </div>
                    </a>
                </li>`).join("");
            list.innerHTML = header + items;
        }

        async function load() {
            const res = await fetch("/Notifications/GetNotifications");
            const data = await res.json();
            notifications = data.notifications;
            loaded = true;
            renderList();
            updateBadge();
        }

        list.addEventListener("click", async (e) => {
            const markAllBtn = e.target.closest(".aris-notif-markall");
            if (markAllBtn) {
                e.preventDefault();
                await fetch("/Notifications/MarkAllAsRead", { method: "POST" });
                notifications.forEach(n => n.isRead = true);
                renderList();
                updateBadge();
                return;
            }

            const item = e.target.closest(".aris-notif-item");
            if (!item) return;
            const id = parseInt(item.dataset.id);
            const n = notifications.find(x => x.id === id);
            if (n && !n.isRead) {
                fetch(`/Notifications/MarkAsRead?id=${id}`, { method: "POST" }).catch(() => {});
                n.isRead = true;
                item.classList.remove("unread");
                updateBadge();
            }
        });

        bellBtn.addEventListener("click", () => {
            if (!loaded) load();
        });

        if (window.ArisChat) {
            ArisChat.onNotification((n) => {
                notifications.unshift(n);
                renderList();
                updateBadge();
            });
            ArisChat.start().then(load);
        } else {
            load();
        }
    }

    return { init };
})();
