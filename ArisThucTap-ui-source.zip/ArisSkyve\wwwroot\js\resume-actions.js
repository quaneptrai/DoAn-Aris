// Shared rename/delete handlers for the "My CVs" list — reused by the standalone
// /Resume/Index page and the CVs tab injected into Profile/Index via AJAX, since event
// delegation on document works regardless of when the .resume-card nodes appear.
$(document).on('click', '.rename-resume-btn', function () {
    const id = $(this).data('id');
    const card = $(`.resume-card[data-resume-id="${id}"]`);
    const currentLabel = card.find('.resume-label').text().trim();
    const label = prompt('Đặt tên cho CV này:', currentLabel);
    if (!label || !label.trim()) return;

    $.post('/Resume/RenameResume', { resumeId: id, label: label.trim() })
        .done(function (res) {
            if (res.success) { card.find('.resume-label').text(label.trim()); }
            else { alert(res.message || 'Không thể đổi tên.'); }
        })
        .fail(function () { alert('Lỗi kết nối.'); });
});

$(document).on('click', '.delete-resume-btn', function () {
    const id = $(this).data('id');
    if (!confirm('Xoá CV này? Hành động này không thể hoàn tác.')) return;

    $.post('/Resume/DeleteResume', { resumeId: id })
        .done(function (res) {
            if (res.success) { $(`.resume-card[data-resume-id="${id}"]`).fadeOut(200, function () { $(this).remove(); }); }
            else { alert(res.message || 'Không thể xoá.'); }
        })
        .fail(function () { alert('Lỗi kết nối.'); });
});
