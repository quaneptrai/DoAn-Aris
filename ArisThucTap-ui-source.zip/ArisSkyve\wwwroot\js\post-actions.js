// Edit/delete handlers for a user's own posts on the Profile "Posts" tab.
// Event delegation on document, same convention as resume-actions.js, since
// this tab's content can be re-rendered/injected rather than always present
// on initial page load.
$(document).on('click', '.delete-post-btn', function () {
    const id = $(this).data('id');
    if (!confirm('Xoá bài viết này? Hành động này không thể hoàn tác.')) return;

    $.ajax({ url: `/Dashboard/DeletePost?id=${id}`, method: 'DELETE' })
        .done(function (res) {
            if (res.success) { $(`[data-post-id="${id}"]`).fadeOut(200, function () { $(this).remove(); }); }
            else { alert(res.message || 'Không thể xoá.'); }
        })
        .fail(function () { alert('Lỗi kết nối.'); });
});

$(document).on('click', '.edit-post-btn', function () {
    const id = $(this).data('id');
    const card = $(`[data-post-id="${id}"]`);
    if (card.hasClass('editing')) return;
    card.addClass('editing');

    const textEl = card.find('.post-content-text');
    const original = textEl.text().trim();

    const textarea = $('<textarea class="form-control form-control-aris mb-2" rows="3"></textarea>').val(original);
    const actions = $(
        '<div class="d-flex gap-2 justify-content-end mb-2">' +
        '  <button type="button" class="btn btn-light btn-sm rounded-pill px-3 cancel-edit-post-btn">Hủy</button>' +
        '  <button type="button" class="btn btn-primary-aris btn-sm rounded-pill px-3 save-edit-post-btn">Lưu</button>' +
        '</div>'
    );

    textEl.hide().after(textarea, actions);
    textarea.trigger('focus');

    function exitEditMode() {
        textarea.remove();
        actions.remove();
        textEl.show();
        card.removeClass('editing');
    }

    actions.find('.cancel-edit-post-btn').on('click', exitEditMode);

    actions.find('.save-edit-post-btn').on('click', function () {
        const newContent = textarea.val().trim();
        if (!newContent) { alert('Nội dung bài viết không được để trống.'); return; }

        $.post('/Dashboard/EditPost', { id: id, content: newContent })
            .done(function (res) {
                if (res.success) {
                    textEl.text(res.content);
                    exitEditMode();
                } else {
                    alert(res.message || 'Không thể lưu.');
                }
            })
            .fail(function () { alert('Lỗi kết nối.'); });
    });
});
