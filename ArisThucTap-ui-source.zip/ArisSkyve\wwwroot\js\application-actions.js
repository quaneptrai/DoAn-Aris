// Shared withdraw handler for the "My Applications" list — reused by the standalone
// /JobApplications/MyApplications page and the Applications tab injected into
// Profile/Index via AJAX.
$(document).on('click', '.withdraw-application-btn', function () {
    if (!confirm('Bạn có chắc muốn rút đơn ứng tuyển này?')) return;
    const id = $(this).data('id');
    $.post('/JobApplications/Withdraw', { applicationId: id })
        .done(function (res) {
            if (res.success) {
                $(`.application-card[data-application-id="${id}"]`).fadeOut(200, function () { $(this).remove(); });
            } else {
                alert(res.message || 'Có lỗi xảy ra.');
            }
        })
        .fail(function () { alert('Lỗi kết nối.'); });
});
