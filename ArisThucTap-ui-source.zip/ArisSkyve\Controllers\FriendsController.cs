using ArisSkyve.Domain.Entities;
using ArisSkyve.Hubs;
using ArisSkyve.Infrastructure.Data.Context;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace ArisSkyve.Controllers
{
    [Authorize]
    public class FriendsController : Controller
    {
        private readonly ArisDBContext _context;

        public FriendsController(ArisDBContext context)
        {
            _context = context;
        }

        private int CurrentUserId => int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

        [HttpGet]
        public async Task<IActionResult> GetFriends()
        {
            var myId = CurrentUserId;

            var friendships = await _context.Friendships
                .Include(f => f.Requester).ThenInclude(u => u.Profile)
                .Include(f => f.Addressee).ThenInclude(u => u.Profile)
                .Where(f => f.Status == FriendshipStatus.Accepted && (f.RequesterId == myId || f.AddresseeId == myId))
                .ToListAsync();

            var friends = friendships.Select(f =>
            {
                var friend = f.RequesterId == myId ? f.Addressee : f.Requester;
                return new
                {
                    userId = friend.Id,
                    username = friend.Username,
                    avatar = friend.Profile?.AvatarUrl ?? "/images/default-avatar.png",
                    isOnline = friend.ShowActiveStatus && ChatHub.IsConnected(friend.Id)
                };
            }).OrderBy(f => f.username).ToList();

            return Json(friends);
        }

        [HttpGet]
        public async Task<IActionResult> GetPendingRequests()
        {
            var myId = CurrentUserId;

            var incoming = await _context.Friendships
                .Include(f => f.Requester).ThenInclude(u => u.Profile)
                .Where(f => f.Status == FriendshipStatus.Pending && f.AddresseeId == myId)
                .Select(f => new
                {
                    requestId = f.Id,
                    userId = f.Requester.Id,
                    username = f.Requester.Username,
                    avatar = f.Requester.Profile != null ? f.Requester.Profile.AvatarUrl : null
                })
                .ToListAsync();

            var outgoing = await _context.Friendships
                .Include(f => f.Addressee).ThenInclude(u => u.Profile)
                .Where(f => f.Status == FriendshipStatus.Pending && f.RequesterId == myId)
                .Select(f => new
                {
                    requestId = f.Id,
                    userId = f.Addressee.Id,
                    username = f.Addressee.Username,
                    avatar = f.Addressee.Profile != null ? f.Addressee.Profile.AvatarUrl : null
                })
                .ToListAsync();

            return Json(new { incoming, outgoing });
        }

        [HttpPost]
        public async Task<IActionResult> SendRequest(int userId)
        {
            var myId = CurrentUserId;
            if (userId == myId) return Json(new { success = false, message = "Bạn không thể tự kết bạn với chính mình." });

            var targetExists = await _context.Users.AnyAsync(u => u.Id == userId);
            if (!targetExists) return NotFound();

            var existing = await _context.Friendships.FirstOrDefaultAsync(f =>
                (f.RequesterId == myId && f.AddresseeId == userId) ||
                (f.RequesterId == userId && f.AddresseeId == myId));

            if (existing != null)
            {
                if (existing.Status == FriendshipStatus.Accepted)
                    return Json(new { success = false, message = "Hai bạn đã là bạn bè." });

                // They already sent me a request — accept it instead of creating a duplicate.
                if (existing.RequesterId == userId)
                {
                    existing.Status = FriendshipStatus.Accepted;
                    existing.RespondedAt = DateTime.UtcNow;
                    await _context.SaveChangesAsync();
                    return Json(new { success = true, status = "friends" });
                }

                return Json(new { success = false, message = "Lời mời kết bạn đã được gửi trước đó." });
            }

            var friendship = new Friendship { RequesterId = myId, AddresseeId = userId };
            _context.Friendships.Add(friendship);

            _context.Notifications.Add(new Notification
            {
                UserId = userId,
                ActorId = myId,
                Type = "FriendRequest",
                Content = "đã gửi cho bạn một lời mời kết bạn.",
                Link = "/Chat/Index?networkTab=requests",
                CreatedAt = DateTime.UtcNow
            });

            await _context.SaveChangesAsync();
            return Json(new { success = true, status = "pending_sent" });
        }

        [HttpPost]
        public async Task<IActionResult> AcceptRequest(int requestId)
        {
            var myId = CurrentUserId;
            var friendship = await _context.Friendships.FirstOrDefaultAsync(f => f.Id == requestId && f.AddresseeId == myId);
            if (friendship == null) return NotFound();

            friendship.Status = FriendshipStatus.Accepted;
            friendship.RespondedAt = DateTime.UtcNow;

            _context.Notifications.Add(new Notification
            {
                UserId = friendship.RequesterId,
                ActorId = myId,
                Type = "FriendRequestAccepted",
                Content = "đã chấp nhận lời mời kết bạn của bạn.",
                Link = "/Chat/Index?networkTab=friends",
                CreatedAt = DateTime.UtcNow
            });

            await _context.SaveChangesAsync();
            return Json(new { success = true });
        }

        [HttpPost]
        public async Task<IActionResult> DeclineRequest(int requestId)
        {
            var myId = CurrentUserId;
            var friendship = await _context.Friendships.FirstOrDefaultAsync(f => f.Id == requestId && f.AddresseeId == myId);
            if (friendship == null) return NotFound();

            _context.Friendships.Remove(friendship);
            await _context.SaveChangesAsync();
            return Json(new { success = true });
        }

        [HttpPost]
        public async Task<IActionResult> CancelRequest(int requestId)
        {
            var myId = CurrentUserId;
            var friendship = await _context.Friendships.FirstOrDefaultAsync(f => f.Id == requestId && f.RequesterId == myId);
            if (friendship == null) return NotFound();

            _context.Friendships.Remove(friendship);
            await _context.SaveChangesAsync();
            return Json(new { success = true });
        }

        [HttpPost]
        public async Task<IActionResult> RemoveFriend(int userId)
        {
            var myId = CurrentUserId;
            var friendship = await _context.Friendships.FirstOrDefaultAsync(f =>
                f.Status == FriendshipStatus.Accepted &&
                ((f.RequesterId == myId && f.AddresseeId == userId) || (f.RequesterId == userId && f.AddresseeId == myId)));

            if (friendship == null) return NotFound();

            _context.Friendships.Remove(friendship);
            await _context.SaveChangesAsync();
            return Json(new { success = true });
        }
    }
}
