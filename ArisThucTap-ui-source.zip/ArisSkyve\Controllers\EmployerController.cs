using ArisSkyve.Application.DTOs;
using ArisSkyve.Domain.Entities;
using ArisSkyve.Infrastructure.Data.Context;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace ArisSkyve.Controllers
{
    // Dedicated landing page for Business-role accounts: an overview (active/closed jobs,
    // applicant totals, a status funnel) plus quick actions, instead of the stats that used
    // to live bolted onto the Business branch of Views/Jobs/Index.cshtml. Posting/editing a
    // job and managing applicants still happen on Jobs/Index (its modals do the real work);
    // this page links into them rather than re-implementing that UI a second time.
    [Authorize]
    public class EmployerController : Controller
    {
        private readonly ArisDBContext _context;

        public EmployerController(ArisDBContext context)
        {
            _context = context;
        }

        private int CurrentUserId => int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

        private static readonly (string Status, string Label)[] FunnelOrder =
        {
            (JobApplicationStatus.Submitted, "Submitted"),
            (JobApplicationStatus.UnderReview, "Under Review"),
            (JobApplicationStatus.Shortlisted, "Shortlisted"),
            (JobApplicationStatus.InterviewScheduled, "Interview"),
            (JobApplicationStatus.Offered, "Offered"),
            (JobApplicationStatus.Rejected, "Rejected"),
        };

        public async Task<IActionResult> Index()
        {
            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == CurrentUserId);
            if (user?.Profile is not BussinessAccount business)
                return RedirectToAction("Index", "Jobs");

            var jobs = await _context.JobPostings
                .Where(j => j.BusinessAccountId == business.Id)
                .OrderByDescending(j => j.CreatedAt)
                .Select(j => new BusinessJobSummaryViewModel
                {
                    Id = j.Id,
                    Title = j.Title,
                    Salary = j.Salary,
                    CreatedAt = j.CreatedAt,
                    IsActive = j.isActive,
                    ApplicantCount = _context.JobApplications.Count(a => a.JobPostingId == j.Id && a.Status != JobApplicationStatus.Withdrawn)
                })
                .ToListAsync();

            var jobIds = jobs.Select(j => j.Id).ToList();
            var sevenDaysAgo = DateTime.UtcNow.AddDays(-7);

            var applications = await _context.JobApplications
                .Where(a => jobIds.Contains(a.JobPostingId) && a.Status != JobApplicationStatus.Withdrawn)
                .Select(a => new { a.Status, a.AppliedAt })
                .ToListAsync();

            var statusBreakdown = FunnelOrder
                .Select(f => new StatusCountViewModel
                {
                    Status = f.Status,
                    Label = f.Label,
                    Count = applications.Count(a => a.Status == f.Status)
                })
                .ToList();

            var model = new EmployerDashboardViewModel
            {
                CompanyId = business.Id,
                CompanyName = business.CompanyName,
                AvatarUrl = business.AvatarUrl,
                IsVerified = business.IsVerified,
                ActiveJobCount = jobs.Count(j => j.IsActive),
                ClosedJobCount = jobs.Count(j => !j.IsActive),
                TotalApplicants = applications.Count,
                NewApplicantsLast7Days = applications.Count(a => a.AppliedAt >= sevenDaysAgo),
                StatusBreakdown = statusBreakdown,
                Jobs = jobs
            };

            return View(model);
        }
    }
}
