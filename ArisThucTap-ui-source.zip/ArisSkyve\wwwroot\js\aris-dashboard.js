(() => {
    document.addEventListener('DOMContentLoaded', () => {
        const card = document.querySelector('.feed-composer-card');
        const input = document.getElementById('postInput');
        const details = document.getElementById('composerDetails');
        if (!card || !input || !details) return;
        function expand() {
            card.classList.add('is-expanded');
            details.inert = false;
            input.setAttribute('aria-expanded', 'true');
            input.style.height = `${Math.min(320, Math.max(100, input.scrollHeight))}px`;
        }
        function collapse() {
            // Collapsing only changes presentation; drafts and attachments remain intact.
            card.classList.remove('is-expanded');
            details.inert = true;
            input.setAttribute('aria-expanded', 'false');
            input.style.height = '36px';
        }
        input.setAttribute('aria-controls', 'composerDetails');
        input.setAttribute('aria-expanded', 'false');
        input.addEventListener('focus', expand);
        input.addEventListener('input', () => {
            input.style.height = '100px';
            input.style.height = `${Math.min(320, Math.max(100, input.scrollHeight))}px`;
        });
        document.getElementById('collapseComposer')?.addEventListener('click', () => {
            collapse();
            input.focus({ preventScroll: true });
            collapse();
        });
        card.addEventListener('keydown', e => { if (e.key === 'Escape') { e.stopPropagation(); input.focus(); collapse(); } });
        input.addEventListener('click', expand);
    });
})();
