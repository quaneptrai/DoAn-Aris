using ArisSkyve.Domain.Entities;
using ArisSkyve.Hubs;
using ArisSkyve.Infrastructure.Data.Context;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Security.Claims;

namespace ArisSkyve.Controllers
{
    public class DashboardController : Controller
    {
        private static readonly HashSet<string> AllowedImageTypes = new()
        {
            "image/jpeg", "image/png", "image/webp", "image/gif"
        };
        private static readonly HashSet<string> AllowedVideoTypes = new()
        {
            "video/mp4", "video/webm", "video/quicktime", "video/x-matroska"
        };

        public ArisDBContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpClientFactory _httpClientFactory;

        public DashboardController(ArisDBContext context, IConfiguration config, IHttpClientFactory httpClientFactory)
        {
            _context = context;
            _config = config;
            _httpClientFactory = httpClientFactory;
        }

        [Authorize]
        public async Task<IActionResult> Index()
        {
            // Lấy ID từ Claim
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim)) return RedirectToAction("Login", "Account");

            int userId = int.Parse(userIdClaim);

            // Lấy thông tin User kèm Profile và danh sách Posts (Sắp xếp mới nhất lên đầu)
            var user = _context.Users
                .Include(u => u.Profile)
                .Include(u => u.Profile.Education)
                .FirstOrDefault(u => u.Id == userId);
            var posts = await _context.Posts
                            .Include(p => p.User)
                                .ThenInclude(u => u.Profile)
                            .Include(p => p.PostMedias)
                            .OrderByDescending(p => p.CreatedAt)
                            .Take(10)
                            .ToListAsync();

            var postIds = posts.Select(p => p.Id).ToList();
            var likedPostIds = await _context.Likes
                .Where(l => l.UserId == userId && postIds.Contains(l.PostId))
                .Select(l => l.PostId)
                .ToListAsync();

            ViewBag.Posts = posts;
            ViewBag.CurrentUserId = userId;
            ViewBag.LikedPostIds = new HashSet<int>(likedPostIds);
            ViewBag.ActiveJobCount = await _context.JobPostings.CountAsync(j => j.isActive);
            ViewBag.OnlineFriendsCount = await CountOnlineFriendsAsync(userId);

            if (user?.Profile != null)
            {
                ViewBag.HasCv = await _context.Resumes.AnyAsync(r => r.EmployeeId == user.Profile.Id);
                ViewBag.AppliedCount = await _context.JobApplications.CountAsync(a => a.ApplicantId == user.Profile.Id && a.Status != "Withdrawn");
                ViewBag.UpcomingInterview = await _context.JobApplications
                    .Include(a => a.JobPosting)
                    .Where(a => a.ApplicantId == user.Profile.Id && a.Status == "InterviewScheduled" && a.InterviewAt >= DateTime.UtcNow)
                    .OrderBy(a => a.InterviewAt)
                    .FirstOrDefaultAsync();
            }
            else
            {
                ViewBag.HasCv = false;
                ViewBag.AppliedCount = 0;
                ViewBag.UpcomingInterview = null;
            }

            ViewBag.RecentJobs = await _context.JobPostings
                .Include(j => j.Locations)
                .Include(j => j.BusinessAccount)
                .Where(j => j.isActive)
                .OrderByDescending(j => j.CreatedAt)
                .Take(3)
                .ToListAsync();

            return View(user);
        }

        // Backs the hero's live stat chips — polled from the client every ~30s so the
        // numbers feel current without needing a full SignalR push just for a counter.
        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetLiveStats()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim)) return Unauthorized();
            int userId = int.Parse(userIdClaim);

            var activeJobCount = await _context.JobPostings.CountAsync(j => j.isActive);
            var onlineFriendsCount = await CountOnlineFriendsAsync(userId);

            return Json(new { activeJobCount, onlineFriendsCount });
        }

        private async Task<int> CountOnlineFriendsAsync(int userId)
        {
            var friendUserIds = await _context.Friendships
                .Where(f => f.Status == FriendshipStatus.Accepted && (f.RequesterId == userId || f.AddresseeId == userId))
                .Select(f => f.RequesterId == userId ? f.AddresseeId : f.RequesterId)
                .ToListAsync();

            if (friendUserIds.Count == 0) return 0;

            var showStatusIds = await _context.Users
                .Where(u => friendUserIds.Contains(u.Id) && u.ShowActiveStatus)
                .Select(u => u.Id)
                .ToListAsync();

            return showStatusIds.Count(id => ChatHub.IsConnected(id));
        }

        [HttpPost]
        [Authorize]
        // Bổ sung string title vào tham số nhận từ AJAX
        public async Task<IActionResult> CreatePost(string content, string title, List<IFormFile>? mediaFiles)
        {
            bool hasMedia = mediaFiles != null && mediaFiles.Count > 0;
            // Article mode có thể chỉ đính kèm ảnh/video mà không cần nội dung chữ,
            // nên chỉ chặn khi cả content, title lẫn media đều trống.
            if (!string.IsNullOrWhiteSpace(content) || !string.IsNullOrWhiteSpace(title) || hasMedia)
            {
                var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                if (string.IsNullOrEmpty(userIdClaim))
                    return Json(new { success = false, message = "User not authenticated" });

                int userId = int.Parse(userIdClaim);

                var post = new Post
                {
                    Content = content ?? string.Empty,
                    UserId = userId,
                    CreatedAt = DateTime.UtcNow,
                    IsPublic = true,
                    // FIX TẠI ĐÂY: Nếu có title thì lưu title, không thì để null hoặc rỗng
                    Title = !string.IsNullOrEmpty(title) ? title : null
                };

                _context.Posts.Add(post);
                await _context.SaveChangesAsync();

                if (hasMedia)
                {
                    var uploaded = await UploadPostMediaAsync(mediaFiles!);
                    if (uploaded.Count > 0)
                    {
                        foreach (var (url, type) in uploaded)
                        {
                            _context.PostMedias.Add(new PostMedias
                            {
                                PostId = post.Id,
                                MediaUrl = url,
                                MediaType = type
                            });
                        }
                        await _context.SaveChangesAsync();
                    }
                }

                var postWithUser = await _context.Posts
                    .Include(p => p.User)
                    .ThenInclude(u => u.Profile)
                    .Include(p => p.PostMedias)
                    .FirstOrDefaultAsync(p => p.Id == post.Id);

                return Json(new
                {
                    success = true,
                    data = new
                    {
                        id = postWithUser.Id,
                        username = postWithUser.User.Username,
                        avatar = postWithUser.User.Profile?.AvatarUrl ?? "/images/default-avatar.png",
                        content = postWithUser.Content,
                        title = postWithUser.Title, // Gửi title về lại cho JS
                        time = "Vừa xong",
                        isArticle = !string.IsNullOrEmpty(postWithUser.Title), // Báo cho JS biết đây là Article
                        media = postWithUser.PostMedias.Select(m => new { url = m.MediaUrl, type = m.MediaType }),
                        likeCount = 0,
                        commentCount = 0,
                        isLiked = false
                    }
                });
            }
            return Json(new { success = false, message = "Dữ liệu không hợp lệ" });
        }

        // Đẩy từng file (ảnh/video) lên AiCore (MinIO) và trả về (url, type) của những file
        // upload thành công. File có content-type không hợp lệ hoặc upload lỗi sẽ bị bỏ qua
        // thay vì làm hỏng cả bài đăng.
        private async Task<List<(string Url, string Type)>> UploadPostMediaAsync(List<IFormFile> files)
        {
            var results = new List<(string, string)>();
            var aiCoreBaseUrl = _config["AiCore:BaseUrl"];
            var client = _httpClientFactory.CreateClient();

            foreach (var file in files)
            {
                if (file.Length == 0) continue;

                string endpoint;
                string mediaType;
                if (AllowedImageTypes.Contains(file.ContentType))
                {
                    endpoint = "/upload-image";
                    mediaType = "image";
                }
                else if (AllowedVideoTypes.Contains(file.ContentType))
                {
                    endpoint = "/upload-video";
                    mediaType = "video";
                }
                else
                {
                    continue;
                }

                try
                {
                    using var content = new MultipartFormDataContent();
                    using var stream = file.OpenReadStream();
                    var streamContent = new StreamContent(stream);
                    streamContent.Headers.ContentType = new MediaTypeHeaderValue(file.ContentType);
                    content.Add(streamContent, "file", file.FileName);

                    var response = await client.PostAsync($"{aiCoreBaseUrl}{endpoint}", content);
                    if (!response.IsSuccessStatusCode) continue;

                    var result = await response.Content.ReadFromJsonAsync<AiCoreUploadResult>();
                    if (result?.Url != null)
                    {
                        results.Add((result.Url, mediaType));
                    }
                }
                catch (Exception)
                {
                    // Bỏ qua file lỗi upload, không chặn việc đăng bài với các media còn lại.
                }
            }

            return results;
        }

        private class AiCoreUploadResult
        {
            public string? Message { get; set; }
            public string? Filename { get; set; }
            public string? Url { get; set; }
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> ToggleLike(int postId)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim))
                return Json(new { success = false, message = "User not authenticated" });
            int userId = int.Parse(userIdClaim);

            var post = await _context.Posts.FirstOrDefaultAsync(p => p.Id == postId);
            if (post == null) return NotFound();

            var existing = await _context.Likes.FirstOrDefaultAsync(l => l.UserId == userId && l.PostId == postId);
            bool liked;
            if (existing != null)
            {
                _context.Likes.Remove(existing);
                post.LikeCount = Math.Max(0, post.LikeCount - 1);
                liked = false;
            }
            else
            {
                _context.Likes.Add(new Like { UserId = userId, PostId = postId, CreatedAt = DateTime.UtcNow });
                post.LikeCount += 1;
                liked = true;
            }
            await _context.SaveChangesAsync();

            return Json(new { success = true, liked, likeCount = post.LikeCount });
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetComments(int postId)
        {
            var comments = await _context.Comments
                .Include(c => c.User).ThenInclude(u => u.Profile)
                .Where(c => c.PostId == postId)
                .OrderBy(c => c.CreatedAt)
                .Select(c => new
                {
                    id = c.Id,
                    username = c.User.Username,
                    avatar = c.User.Profile != null ? c.User.Profile.AvatarUrl : "/images/default-avatar.png",
                    content = c.Content,
                    createdAt = c.CreatedAt
                })
                .ToListAsync();

            return Json(comments);
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> AddComment(int postId, string content)
        {
            if (string.IsNullOrWhiteSpace(content))
                return Json(new { success = false, message = "Bình luận không được để trống" });

            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim))
                return Json(new { success = false, message = "User not authenticated" });
            int userId = int.Parse(userIdClaim);

            var post = await _context.Posts.FirstOrDefaultAsync(p => p.Id == postId);
            if (post == null) return NotFound();

            var comment = new Comment
            {
                Content = content.Trim(),
                UserId = userId,
                PostId = postId,
                CreatedAt = DateTime.UtcNow
            };
            _context.Comments.Add(comment);
            post.CommentCount += 1;
            await _context.SaveChangesAsync();

            var user = await _context.Users.Include(u => u.Profile).FirstAsync(u => u.Id == userId);

            return Json(new
            {
                success = true,
                commentCount = post.CommentCount,
                comment = new
                {
                    id = comment.Id,
                    username = user.Username,
                    avatar = user.Profile?.AvatarUrl ?? "/images/default-avatar.png",
                    content = comment.Content,
                    createdAt = comment.CreatedAt
                }
            });
        }

        // THÊM HÀM XÓA BÀI VIẾT
        [HttpDelete]
        [Authorize]
        public async Task<IActionResult> DeletePost(int id)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim)) return Json(new { success = false });

            int userId = int.Parse(userIdClaim);

            // Tìm bài viết và check xem có đúng chủ sở hữu không
            var post = await _context.Posts.FirstOrDefaultAsync(p => p.Id == id && p.UserId == userId);

            if (post == null)
            {
                return Json(new { success = false, message = "Bài viết không tồn tại hoặc bạn không có quyền xóa." });
            }

            try
            {
                // Likes.PostId is FK NoAction (can't be Cascade — SQL Server rejects it
                // due to Likes also cascading from Users, a conflicting cascade path),
                // so clean up child rows explicitly before removing the post itself.
                var likes = _context.Likes.Where(l => l.PostId == id);
                var comments = _context.Comments.Where(c => c.PostId == id);
                var medias = _context.PostMedias.Where(m => m.PostId == id);
                _context.Likes.RemoveRange(likes);
                _context.Comments.RemoveRange(comments);
                _context.PostMedias.RemoveRange(medias);
                _context.Posts.Remove(post);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                return Json(new { success = false, message = "Không thể xóa bài viết (có thể do dữ liệu liên quan). Vui lòng thử lại." });
            }

            return Json(new { success = true });
        }

        // Sửa bài viết — cùng pattern check chủ sở hữu với DeletePost.
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> EditPost(int id, string content, string? title)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim)) return Json(new { success = false });

            int userId = int.Parse(userIdClaim);

            if (string.IsNullOrWhiteSpace(content))
            {
                return Json(new { success = false, message = "Nội dung bài viết không được để trống." });
            }

            var post = await _context.Posts.FirstOrDefaultAsync(p => p.Id == id && p.UserId == userId);

            if (post == null)
            {
                return Json(new { success = false, message = "Bài viết không tồn tại hoặc bạn không có quyền sửa." });
            }

            post.Content = content.Trim();
            post.Title = string.IsNullOrWhiteSpace(title) ? null : title.Trim();
            post.UpdatedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync();

            return Json(new { success = true, content = post.Content, title = post.Title });
        }
    }
}
