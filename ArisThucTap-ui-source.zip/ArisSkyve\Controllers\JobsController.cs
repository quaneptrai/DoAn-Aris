using ArisSkyve.Application.DTOs;
using ArisSkyve.Domain.Entities;
using ArisSkyve.Infrastructure.Data.Context;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Globalization;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ArisSkyve.Controllers
{

    [Authorize]
    public class JobsController : Controller
    {
        private readonly ArisDBContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpClientFactory _httpClientFactory;

        public JobsController(ArisDBContext context, IConfiguration config, IHttpClientFactory httpClientFactory)
        {
            _context = context;
            _config = config;
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IActionResult> Index(string? q = null, string? location = null, string? category = null, string? workMode = null, string? sort = null)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim)) return RedirectToAction("Login", "Account");
            int userId = int.Parse(userIdClaim);

            var user = await _context.Users
                .Include(u => u.Profile)
                .FirstOrDefaultAsync(u => u.Id == userId);

            var query = _context.JobPostings
                .Include(j => j.Locations)
                .Include(j => j.BusinessAccount)
                .Where(j => j.isActive);

            if (!string.IsNullOrWhiteSpace(q))
            {
                var search = q.Trim().ToLower();
                query = query.Where(j => j.Title.ToLower().Contains(search) || j.Company.ToLower().Contains(search) || j.Category.ToLower().Contains(search));
            }

            if (!string.IsNullOrWhiteSpace(location))
            {
                var loc = location.Trim().ToLower();
                query = query.Where(j => j.Locations.Any(l => l.City.ToLower().Contains(loc) || l.Address.ToLower().Contains(loc)) || j.LocationTags.ToLower().Contains(loc));
            }

            if (!string.IsNullOrWhiteSpace(category))
            {
                query = query.Where(j => j.Category == category);
            }

            if (!string.IsNullOrWhiteSpace(workMode))
            {
                query = query.Where(j => j.WorkTime.Contains(workMode));
            }

            if (sort == "oldest")
            {
                query = query.OrderBy(j => j.CreatedAt);
            }
            else
            {
                query = query.OrderByDescending(j => j.CreatedAt);
            }

            var totalJobsCount = await query.CountAsync();
            var jobs = await query.Take(10).ToListAsync();

            ViewData["UserRole"] = user?.Role;
            ViewBag.SearchQuery = q;
            ViewBag.SearchLocation = location;
            ViewBag.SelectedCategory = category;
            ViewBag.SelectedWorkMode = workMode;
            ViewBag.SelectedSort = sort;
            ViewBag.TotalJobsCount = totalJobsCount;

            var model = new JobsIndexViewModel
            {
                User = user,
                Profile = user?.Profile,
                JobPostings = jobs,
                RecommendedJobs = new List<JobRecommendationDTO>()
            };

            if (user?.Profile != null && user.Role == "Business")
            {
                model.MyJobPostings = await _context.JobPostings
                    .Include(j => j.Locations)
                    .Where(j => j.BusinessAccountId == user.Profile.Id)
                    .OrderByDescending(j => j.CreatedAt)
                    .Select(j => new BusinessJobSummaryViewModel
                    {
                        Id = j.Id,
                        Title = j.Title,
                        Salary = j.Salary,
                        CreatedAt = j.CreatedAt,
                        IsActive = j.isActive,
                        ApplicantCount = _context.JobApplications.Count(a => a.JobPostingId == j.Id && a.Status != "Withdrawn")
                    })
                    .ToListAsync();
            }
            else if (user?.Profile != null && user.Role == "Employee")
            {
                ViewBag.AppliedJobsCount = await _context.JobApplications
                    .CountAsync(a => a.ApplicantId == user.Profile.Id && a.Status != "Withdrawn");
            }

            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
            var job = await _context.JobPostings
                .Include(j => j.Locations)
                .Include(j => j.BusinessAccount)
                .FirstOrDefaultAsync(j => j.Id == id);

            if (job == null) return NotFound();

            return View(job);
        }

        [HttpGet]
        public async Task<IActionResult> GetAiRecommendations(int topK = 3)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim)) return Content("");
            int currentUserId = int.Parse(userIdClaim);

            var profile = await _context.Profiles.FirstOrDefaultAsync(p => p.UserId == currentUserId);
            if (profile == null) return Content("<div class='p-3 text-muted text-center'>Vui lòng cập nhật hồ sơ cá nhân để nhận gợi ý việc làm.</div>");

            var resume = await _context.Resumes.FirstOrDefaultAsync(r => r.EmployeeId == profile.Id);
            if (resume == null) return Content("<div class='p-3 text-muted text-center'>Hãy tạo hoặc tải lên CV để nhận gợi ý việc làm phù hợp.</div>");

            DateTime currentResumeVersion = resume.LastUpdatedAt;

            // 1. Kiểm tra xem trong DB đã có bao nhiêu gợi ý cho version Resume này rồi
            var existingRecs = await _context.UserRecommendations
                .Where(r => r.UserId == currentUserId && r.ResumeVersion == currentResumeVersion)
                .OrderByDescending(r => r.MatchScore)
                .ToListAsync();

            // 2. Nếu số lượng trong DB đã đủ (hoặc nhiều hơn) topK yêu cầu -> Trả về luôn, không gọi AI nữa
            if (existingRecs.Count >= topK)
            {
                var savedJobIds = existingRecs.Take(topK).Select(r => r.JobId).ToList();
                var cachedJobs = await _context.JobPostings
                    .Include(j => j.Locations)
                    .Where(j => savedJobIds.Contains(j.Id) && j.isActive)
                    .ToListAsync();

                // Map lại đúng Score và Reason từ existingRecs
                var resultDto = cachedJobs.Select(j => new JobRecommendationDTO
                {
                    Id = j.Id,
                    JobTitle = j.Title,
                    Category = j.Category,
                    Score = existingRecs.First(r => r.JobId == j.Id).MatchScore,
                    Reason = existingRecs.First(r => r.JobId == j.Id).Reason
                }).OrderByDescending(x => x.Score).ToList();

                return PartialView("_RecommendedJobsPartial", resultDto);
            }

            // 3. Nếu DB chưa đủ topK -> Gọi AI để lấy thêm
            try
            {
                using (var client = new HttpClient())
                {
                    // Gửi topK lớn hơn để AI gợi ý thêm những cái mới
                    var nvc = new List<KeyValuePair<string, string>> {
                        new("employee_id", profile.Id.ToString()),
                        new("top_k", topK.ToString())
                        };

                    var aiCoreBaseUrl = _config["AiCore:BaseUrl"];
                    var response = await client.PostAsync($"{aiCoreBaseUrl}/recommend-jobs-for-employee", new FormUrlEncodedContent(nvc));

                    if (response.IsSuccessStatusCode)
                    {
                        var jsonResponse = await response.Content.ReadAsStringAsync();
                        var result = JsonSerializer.Deserialize<AiResponseWrapper>(jsonResponse, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                        if (result?.Recommendations != null)
                        {
                            foreach (var rec in result.Recommendations)
                            {
                                // Đối chiếu theo OriginalUrl thay vì Title: "job_id" AiCore trả về là hash
                                // Pinecone chứ không phải JobPostings.Id, còn Title có thể trùng giữa
                                // nhiều tin -> match nhầm. OriginalUrl là khóa chung đáng tin cậy duy nhất.
                                var jobInDb = !string.IsNullOrWhiteSpace(rec.OriginalUrl)
                                    ? await _context.JobPostings.FirstOrDefaultAsync(j => j.OriginalUrl == rec.OriginalUrl)
                                    : await _context.JobPostings.FirstOrDefaultAsync(j => j.Title == rec.JobTitle);
                                if (jobInDb != null)
                                {
                                    var isExisted = await _context.UserRecommendations
                                        .AnyAsync(r => r.UserId == currentUserId && r.JobId == jobInDb.Id && r.ResumeVersion == currentResumeVersion);

                                    if (!isExisted)
                                    {
                                        _context.UserRecommendations.Add(new UserRecommendations
                                        {
                                            UserId = currentUserId,
                                            JobId = jobInDb.Id,
                                            MatchScore = rec.Score,
                                            Reason = rec.Reason,
                                            CreatedAt = DateTime.UtcNow,
                                            ResumeVersion = currentResumeVersion
                                        });
                                    }
                                    rec.Id = jobInDb.Id;
                                    rec.Category = jobInDb.Category;
                                }
                            }
                            await _context.SaveChangesAsync();
                            return PartialView("_RecommendedJobsPartial", result.Recommendations.Take(topK).ToList());
                        }
                    }
                }
            }
            catch (Exception ex) { /* Log error */ }

            return Content("<p>Hệ thống đang tìm kiếm thêm...</p>");
        }

        [HttpGet]
        public async Task<IActionResult> GetJobs(int skip = 0, int take = 10, string? q = null, string? location = null, string? category = null, string? workMode = null, string? sort = null)
        {
            var query = _context.JobPostings
                .Include(j => j.Locations)
                .Include(j => j.BusinessAccount)
                .Where(j => j.isActive);

            if (!string.IsNullOrWhiteSpace(q))
            {
                var search = q.Trim().ToLower();
                query = query.Where(j => j.Title.ToLower().Contains(search) || j.Company.ToLower().Contains(search) || j.Category.ToLower().Contains(search));
            }

            if (!string.IsNullOrWhiteSpace(location))
            {
                var loc = location.Trim().ToLower();
                query = query.Where(j => j.Locations.Any(l => l.City.ToLower().Contains(loc) || l.Address.ToLower().Contains(loc)) || j.LocationTags.ToLower().Contains(loc));
            }

            if (!string.IsNullOrWhiteSpace(category))
            {
                query = query.Where(j => j.Category == category);
            }

            if (!string.IsNullOrWhiteSpace(workMode))
            {
                query = query.Where(j => j.WorkTime.Contains(workMode));
            }

            if (sort == "oldest")
            {
                query = query.OrderBy(j => j.CreatedAt);
            }
            else
            {
                query = query.OrderByDescending(j => j.CreatedAt);
            }

            var jobs = await query
                .Skip(skip)
                .Take(take)
                .ToListAsync();

            if (!jobs.Any()) return Json(new { success = false });

            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!string.IsNullOrEmpty(userIdClaim))
            {
                ViewData["UserRole"] = await _context.Users
                    .Where(u => u.Id == int.Parse(userIdClaim))
                    .Select(u => u.Role)
                    .FirstOrDefaultAsync();
            }

            return PartialView("_JobCardPartial", jobs);
        }

        // Đăng tin tuyển dụng thật qua backend của chính ArisSkyve (thay vì JS gọi
        // thẳng sang AiCore như trước — không auth, không gắn được BusinessAccountId).
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> CreateJobPosting([FromBody] CreateJobPostingDto dto)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim))
                return Json(new { success = false, message = "Phiên đăng nhập không hợp lệ." });
            int userId = int.Parse(userIdClaim);

            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == userId);
            if (user == null || user.Role != "Business" || user.Profile is not BussinessAccount business)
            {
                return Json(new { success = false, message = "Chỉ tài khoản doanh nghiệp mới có thể đăng tin tuyển dụng." });
            }

            if (dto == null || string.IsNullOrWhiteSpace(dto.Title) || string.IsNullOrWhiteSpace(dto.Company))
            {
                return Json(new { success = false, message = "Vui lòng nhập đầy đủ tiêu đề và tên công ty." });
            }

            DateTime? deadline = null;
            if (!string.IsNullOrWhiteSpace(dto.Deadline) &&
                DateTime.TryParseExact(dto.Deadline, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out var parsedDeadline))
            {
                deadline = parsedDeadline;
            }

            var job = new JobPosting
            {
                Title = dto.Title,
                Company = dto.Company,
                Responsibilities = JsonSerializer.Serialize(dto.Responsibilities ?? new List<string>()),
                Requirements = JsonSerializer.Serialize(dto.Requirements ?? new List<string>()),
                Benefits = JsonSerializer.Serialize(dto.Benefits ?? new List<string>()),
                WorkTime = dto.WorkTime is { Count: > 0 } ? string.Join(", ", dto.WorkTime) : string.Empty,
                Salary = dto.Salary ?? string.Empty,
                Experience = dto.Experience ?? string.Empty,
                Deadline = deadline,
                Category = dto.Category ?? string.Empty,
                Hashtags = JsonSerializer.Serialize(dto.Keywords ?? new List<string>()),
                LocationTags = JsonSerializer.Serialize(dto.LocationTags ?? new List<string>()),
                FullText = string.IsNullOrWhiteSpace(dto.FullText) ? dto.Title : dto.FullText,
                OriginalUrl = dto.OriginalUrl ?? string.Empty,
                ScreeningQuestions = JsonSerializer.Serialize((dto.ScreeningQuestions ?? new List<string>()).Where(q => !string.IsNullOrWhiteSpace(q)).ToList()),
                BusinessAccountId = business.Id,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            foreach (var locStr in dto.Locations ?? new List<string>())
            {
                if (string.IsNullOrWhiteSpace(locStr)) continue;

                string city = dto.LocationTags is { Count: > 0 } ? dto.LocationTags[0] : "";
                string address = locStr;
                if (locStr.Contains(':'))
                {
                    var parts = locStr.Split(':', 2);
                    city = parts[0].Trim();
                    address = parts[1].Trim();
                }

                job.Locations.Add(new JobLocation
                {
                    City = city.Length > 100 ? city[..100] : city,
                    Address = address.Length > 2000 ? address[..2000] : address
                });
            }

            _context.JobPostings.Add(job);
            await _context.SaveChangesAsync();

            // Fire-and-forget style: auto-share to whichever channels the employer opted into
            // via the Jobs/Index sidebar toggle (SocialConnectController.ToggleAutoShare). A
            // failure here (n8n unreachable, workflow not published, etc.) must never fail the
            // job creation response itself — the manual "Chia sẻ" button remains the fallback.
            var autoShareConnections = await _context.SocialChannelConnections
                .Where(c => c.BusinessAccountId == business.Id && c.IsActive && c.AutoShareEnabled)
                .ToListAsync();
            if (autoShareConnections.Count > 0)
            {
                try
                {
                    var payloadChannels = BuildSharePayloadChannels(job, autoShareConnections, null);
                    await PostJobShareToN8nAsync(job, payloadChannels);
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"DEBUG: Auto-share to n8n failed for job {job.Id}: {ex.Message}");
                }
            }

            return Json(new { success = true, jobId = job.Id });
        }

        // Employer-only: fetches an existing posting's editable fields, in the same shape
        // the create-job form's JSON/PDF prefill handlers already use, so #postJobModal can
        // be reopened in "edit" mode instead of needing a separate edit form/page.
        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetJobPostingForEdit(int id)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim))
                return Json(new { success = false, message = "Phiên đăng nhập không hợp lệ." });
            int userId = int.Parse(userIdClaim);

            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == userId);
            if (user?.Profile is not BussinessAccount business)
                return Json(new { success = false, message = "Chỉ tài khoản doanh nghiệp mới có thể sửa tin." });

            var job = await _context.JobPostings.Include(j => j.Locations).FirstOrDefaultAsync(j => j.Id == id);
            if (job == null) return Json(new { success = false, message = "Không tìm thấy tin tuyển dụng." });
            if (job.BusinessAccountId != business.Id)
                return Json(new { success = false, message = "Bạn không có quyền sửa tin này." });

            return Json(new
            {
                success = true,
                job = new
                {
                    id = job.Id,
                    title = job.Title,
                    company = job.Company,
                    salary = job.Salary,
                    cate = job.Category,
                    deadline = job.Deadline?.ToString("dd/MM/yyyy"),
                    experience = job.Experience,
                    originalUrl = job.OriginalUrl,
                    fullText = job.FullText,
                    responsibilities = ParseJsonList(job.Responsibilities),
                    requirements = ParseJsonList(job.Requirements),
                    screeningQuestions = ParseJsonList(job.ScreeningQuestions),
                    locations = job.Locations.Select(l => string.IsNullOrWhiteSpace(l.City) ? l.Address : $"{l.City}: {l.Address}").ToList(),
                    isActive = job.isActive
                }
            });
        }

        // Employer-only: saves edits made through #postJobModal's edit mode. Mirrors
        // CreateJobPosting's field mapping, but updates the existing row (and replaces its
        // Locations) instead of inserting a new one.
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> UpdateJobPosting(int id, [FromBody] CreateJobPostingDto dto)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim))
                return Json(new { success = false, message = "Phiên đăng nhập không hợp lệ." });
            int userId = int.Parse(userIdClaim);

            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == userId);
            if (user?.Profile is not BussinessAccount business)
                return Json(new { success = false, message = "Chỉ tài khoản doanh nghiệp mới có thể sửa tin." });

            var job = await _context.JobPostings.Include(j => j.Locations).FirstOrDefaultAsync(j => j.Id == id);
            if (job == null) return Json(new { success = false, message = "Không tìm thấy tin tuyển dụng." });
            if (job.BusinessAccountId != business.Id)
                return Json(new { success = false, message = "Bạn không có quyền sửa tin này." });

            if (dto == null || string.IsNullOrWhiteSpace(dto.Title) || string.IsNullOrWhiteSpace(dto.Company))
                return Json(new { success = false, message = "Vui lòng nhập đầy đủ tiêu đề và tên công ty." });

            DateTime? deadline = null;
            if (!string.IsNullOrWhiteSpace(dto.Deadline) &&
                DateTime.TryParseExact(dto.Deadline, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out var parsedDeadline))
            {
                deadline = parsedDeadline;
            }

            job.Title = dto.Title;
            job.Company = dto.Company;
            job.Responsibilities = JsonSerializer.Serialize(dto.Responsibilities ?? new List<string>());
            job.Requirements = JsonSerializer.Serialize(dto.Requirements ?? new List<string>());
            job.Benefits = JsonSerializer.Serialize(dto.Benefits ?? new List<string>());
            job.WorkTime = dto.WorkTime is { Count: > 0 } ? string.Join(", ", dto.WorkTime) : string.Empty;
            job.Salary = dto.Salary ?? string.Empty;
            job.Experience = dto.Experience ?? string.Empty;
            job.Deadline = deadline;
            job.Category = dto.Category ?? string.Empty;
            job.Hashtags = JsonSerializer.Serialize(dto.Keywords ?? new List<string>());
            job.LocationTags = JsonSerializer.Serialize(dto.LocationTags ?? new List<string>());
            job.FullText = string.IsNullOrWhiteSpace(dto.FullText) ? dto.Title : dto.FullText;
            job.OriginalUrl = dto.OriginalUrl ?? string.Empty;
            job.ScreeningQuestions = JsonSerializer.Serialize((dto.ScreeningQuestions ?? new List<string>()).Where(q => !string.IsNullOrWhiteSpace(q)).ToList());
            job.UpdatedAt = DateTime.UtcNow;

            _context.JobLocations.RemoveRange(job.Locations);
            job.Locations.Clear();
            foreach (var locStr in dto.Locations ?? new List<string>())
            {
                if (string.IsNullOrWhiteSpace(locStr)) continue;

                string city = dto.LocationTags is { Count: > 0 } ? dto.LocationTags[0] : "";
                string address = locStr;
                if (locStr.Contains(':'))
                {
                    var parts = locStr.Split(':', 2);
                    city = parts[0].Trim();
                    address = parts[1].Trim();
                }

                job.Locations.Add(new JobLocation
                {
                    City = city.Length > 100 ? city[..100] : city,
                    Address = address.Length > 2000 ? address[..2000] : address
                });
            }

            await _context.SaveChangesAsync();

            return Json(new { success = true, jobId = job.Id });
        }

        // Employer-only: flips a posting between open/closed without deleting it (and its
        // application history) — deactivating hides it from the public feed while keeping
        // it visible on the employer's own list and the company page.
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> ToggleJobActive(int id)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim))
                return Json(new { success = false, message = "Phiên đăng nhập không hợp lệ." });
            int userId = int.Parse(userIdClaim);

            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == userId);
            if (user?.Profile is not BussinessAccount business)
                return Json(new { success = false, message = "Chỉ tài khoản doanh nghiệp mới có thể thao tác." });

            var job = await _context.JobPostings.FirstOrDefaultAsync(j => j.Id == id);
            if (job == null) return Json(new { success = false, message = "Không tìm thấy tin tuyển dụng." });
            if (job.BusinessAccountId != business.Id)
                return Json(new { success = false, message = "Bạn không có quyền thao tác trên tin này." });

            job.isActive = !job.isActive;
            job.UpdatedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync();

            return Json(new { success = true, isActive = job.isActive });
        }

        // Employer-only: powers the "Chia sẻ" modal — connected social channels plus an
        // auto-generated caption the employer can tweak before sending, per channel.
        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetShareOptions(int id)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim))
                return Json(new { success = false, message = "Phiên đăng nhập không hợp lệ." });
            int userId = int.Parse(userIdClaim);

            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == userId);
            if (user?.Profile is not BussinessAccount business)
                return Json(new { success = false, message = "Chỉ tài khoản doanh nghiệp mới có thể chia sẻ tin." });

            var job = await _context.JobPostings.Include(j => j.Locations).FirstOrDefaultAsync(j => j.Id == id);
            if (job == null) return Json(new { success = false, message = "Không tìm thấy tin tuyển dụng." });
            if (job.BusinessAccountId != business.Id)
                return Json(new { success = false, message = "Bạn không có quyền chia sẻ tin này." });

            var channels = await _context.SocialChannelConnections
                .Where(c => c.BusinessAccountId == business.Id && c.IsActive)
                .OrderBy(c => c.Platform)
                .Select(c => new { id = c.Id, platform = c.Platform.ToString(), displayName = c.DisplayName })
                .ToListAsync();

            return Json(new
            {
                success = true,
                channels,
                defaultMessage = BuildDefaultShareCaption(job)
            });
        }

        // Employer-only: sends the job to whichever connected channels were selected, via
        // the n8n webhook that fans it out to the right platform API per channel. Only
        // externalId/access tokens travel in the payload — the shared Zalo bot token stays
        // in n8n's own credential store, never leaves it.
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> ShareJob([FromBody] ShareJobRequestDto dto)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim))
                return Json(new { success = false, message = "Phiên đăng nhập không hợp lệ." });
            int userId = int.Parse(userIdClaim);

            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == userId);
            if (user?.Profile is not BussinessAccount business)
                return Json(new { success = false, message = "Chỉ tài khoản doanh nghiệp mới có thể chia sẻ tin." });

            var job = await _context.JobPostings.Include(j => j.Locations).FirstOrDefaultAsync(j => j.Id == dto.JobId);
            if (job == null) return Json(new { success = false, message = "Không tìm thấy tin tuyển dụng." });
            if (job.BusinessAccountId != business.Id)
                return Json(new { success = false, message = "Bạn không có quyền chia sẻ tin này." });

            if (dto.Channels == null || dto.Channels.Count == 0)
                return Json(new { success = false, message = "Vui lòng chọn ít nhất một kênh." });

            var channelIds = dto.Channels.Select(c => c.ChannelId).ToList();
            var connections = await _context.SocialChannelConnections
                .Where(c => c.BusinessAccountId == business.Id && c.IsActive && channelIds.Contains(c.Id))
                .ToListAsync();

            var overrideMessages = dto.Channels.ToDictionary(c => c.ChannelId, c => c.Message);
            var payloadChannels = BuildSharePayloadChannels(job, connections, overrideMessages);

            var webhookUrl = _config["Social:N8n:WebhookUrl"];
            if (string.IsNullOrWhiteSpace(webhookUrl))
                return Json(new { success = false, message = "Thiếu cấu hình Social:N8n:WebhookUrl trong appsettings." });

            var (success, message, body) = await PostJobShareToN8nAsync(job, payloadChannels);
            if (!success)
                return Json(new { success = false, message, detail = body });

            return Content(body!, "application/json");
        }

        // Builds the per-channel n8n payload shape shared by the manual "Chia sẻ" flow
        // (ShareJob, per-channel caption overrides from the modal) and the auto-share-on-create
        // path (CreateJobPosting, always uses the default caption — overrideMessages is null).
        private static List<object> BuildSharePayloadChannels(JobPosting job, List<SocialChannelConnection> connections, Dictionary<int, string?>? overrideMessages)
        {
            var defaultMessage = BuildDefaultShareCaption(job);
            var payloadChannels = new List<object>();
            foreach (var conn in connections)
            {
                var overrideMsg = overrideMessages != null && overrideMessages.TryGetValue(conn.Id, out var m) ? m : null;
                var message = string.IsNullOrWhiteSpace(overrideMsg) ? defaultMessage : overrideMsg;

                var channel = conn.Platform switch
                {
                    SocialPlatform.FacebookPage => (object)new { channelId = conn.Id, type = "facebook", pageId = conn.ExternalId, accessToken = conn.AccessToken, message },
                    SocialPlatform.ZaloOa => new { channelId = conn.Id, type = "zalo_oa", oaId = conn.ExternalId, accessToken = conn.AccessToken, message },
                    SocialPlatform.ZaloGroup => new { channelId = conn.Id, type = "zalo_group", chatId = conn.ExternalId, message },
                    _ => null
                };
                if (channel != null) payloadChannels.Add(channel);
            }
            return payloadChannels;
        }

        // Posts the fanned-out job-share request to the n8n webhook. Only externalId/access
        // tokens travel in the payload — the shared Zalo bot token stays in n8n's own
        // credential store, never leaves it.
        private async Task<(bool success, string message, string? body)> PostJobShareToN8nAsync(JobPosting job, List<object> payloadChannels)
        {
            var webhookUrl = _config["Social:N8n:WebhookUrl"];
            if (string.IsNullOrWhiteSpace(webhookUrl))
                return (false, "Thiếu cấu hình Social:N8n:WebhookUrl trong appsettings.", null);

            var payload = new
            {
                jobId = job.Id,
                title = job.Title,
                company = job.Company,
                applyUrl = Url.Action("Details", "Jobs", new { id = job.Id }, Request.Scheme),
                channels = payloadChannels
            };

            var client = _httpClientFactory.CreateClient();
            using var request = new HttpRequestMessage(HttpMethod.Post, webhookUrl)
            {
                Content = new StringContent(JsonSerializer.Serialize(payload), System.Text.Encoding.UTF8, "application/json")
            };
            var webhookSecret = _config["Social:N8n:WebhookSecret"];
            if (!string.IsNullOrWhiteSpace(webhookSecret))
                request.Headers.Add("X-Webhook-Secret", webhookSecret);

            try
            {
                var response = await client.SendAsync(request);
                var body = await response.Content.ReadAsStringAsync();
                if (!response.IsSuccessStatusCode)
                    return (false, "n8n từ chối yêu cầu.", body);

                return (true, "OK", body);
            }
            catch (HttpRequestException)
            {
                return (false, "Không thể kết nối tới n8n.", null);
            }
        }

        private static string BuildDefaultShareCaption(JobPosting job)
        {
            var locations = job.Locations is { Count: > 0 }
                ? string.Join(", ", job.Locations.Select(l => string.IsNullOrWhiteSpace(l.City) ? l.Address : l.City).Distinct())
                : "Nhiều địa điểm";
            var salary = string.IsNullOrWhiteSpace(job.Salary) ? "Thỏa thuận" : job.Salary;

            return $"🚀 Tuyển dụng: {job.Title} tại {job.Company}\n" +
                   $"💰 Lương: {salary}\n" +
                   $"📍 Địa điểm: {locations}\n\n" +
                   $"Ứng tuyển ngay trên Aris!";
        }

        private static List<string> ParseJsonList(string? data)
        {
            if (string.IsNullOrWhiteSpace(data)) return new List<string>();
            try
            {
                return JsonSerializer.Deserialize<List<string>>(data) ?? new List<string>();
            }
            catch (JsonException)
            {
                return new List<string>();
            }
        }

        // Proxy file PDF sang AiCore để AI trích xuất thông tin tin tuyển dụng, dùng để
        // tự động điền form đăng tin thay vì HR phải gõ tay lại từ file JD có sẵn.
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> ExtractJobFromPdf(IFormFile? file)
        {
            if (file == null || file.Length == 0)
                return Json(new { success = false, message = "Vui lòng chọn file." });

            var aiCoreBaseUrl = _config["AiCore:BaseUrl"];
            var client = _httpClientFactory.CreateClient();

            try
            {
                using var content = new MultipartFormDataContent();
                using var stream = file.OpenReadStream();
                var streamContent = new StreamContent(stream);
                streamContent.Headers.ContentType = new MediaTypeHeaderValue(
                    string.IsNullOrEmpty(file.ContentType) ? "application/octet-stream" : file.ContentType);
                content.Add(streamContent, "file", file.FileName);

                var response = await client.PostAsync($"{aiCoreBaseUrl}/extract-job-from-pdf", content);
                if (!response.IsSuccessStatusCode)
                {
                    return Json(new { success = false, message = "Không thể trích xuất nội dung từ file." });
                }

                var json = await response.Content.ReadAsStringAsync();
                return Content(json, "application/json");
            }
            catch (Exception)
            {
                return Json(new { success = false, message = "Lỗi kết nối tới dịch vụ AI." });
            }
        }

     }
 }