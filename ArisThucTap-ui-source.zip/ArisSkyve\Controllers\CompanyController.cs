using ArisSkyve.Application.DTOs;
using ArisSkyve.Domain.Entities;
using ArisSkyve.Infrastructure.Data.Context;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace ArisSkyve.Controllers
{
    [Authorize]
    public class CompanyController : Controller
    {
        private readonly ArisDBContext _context;

        public CompanyController(ArisDBContext context)
        {
            _context = context;
        }

        private int CurrentUserId => int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var companies = await _context.BussinessAccounts
                .OrderBy(b => b.CompanyName)
                .Select(b => new CompanyListItemViewModel
                {
                    Id = b.Id,
                    CompanyName = b.CompanyName,
                    Industry = b.Industry,
                    CompanyAddress = b.CompanyAddress,
                    AvatarUrl = b.AvatarUrl,
                    CoverPhotoUrl = b.CoverPhotoUrl,
                    CompanySize = b.CompanySize,
                    IsVerified = b.IsVerified,
                    OpenJobCount = _context.JobPostings.Count(j => j.BusinessAccountId == b.Id && j.isActive)
                })
                .ToListAsync();

            return View(companies);
        }

        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
            var company = await _context.BussinessAccounts.FirstOrDefaultAsync(b => b.Id == id);
            if (company == null) return NotFound();

            // Tin đã hết hạn vẫn hiển thị ở đây (và tìm được qua Search) — chỉ ẩn khỏi
            // trang chủ Jobs/Index, không xoá và không giấu khỏi trang công ty.
            var jobs = await _context.JobPostings
                .Include(j => j.Locations)
                .Where(j => j.BusinessAccountId == id)
                .OrderByDescending(j => j.isActive)
                .ThenByDescending(j => j.CreatedAt)
                .ToListAsync();

            var model = new CompanyDetailsViewModel
            {
                Company = company,
                Jobs = jobs,
                OpenJobCount = jobs.Count(j => j.isActive),
                IsOwner = company.UserId == CurrentUserId
            };

            return View(model);
        }

        // Lets a business account update its own public company profile — separate from
        // the one-shot fields captured at AccountController.UpgradeToBusiness time, which
        // otherwise could never be revisited.
        [HttpGet]
        public async Task<IActionResult> Edit()
        {
            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == CurrentUserId);
            if (user?.Profile is not BussinessAccount business)
                return RedirectToAction("Index", "Jobs");

            return View(business);
        }

        [HttpPost]
        public async Task<IActionResult> Edit([FromForm] UpdateCompanyProfileDto dto)
        {
            var user = await _context.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == CurrentUserId);
            if (user?.Profile is not BussinessAccount business)
                return Json(new { success = false, message = "Chỉ tài khoản doanh nghiệp mới có thể sửa hồ sơ công ty." });

            if (dto == null || string.IsNullOrWhiteSpace(dto.CompanyName))
                return Json(new { success = false, message = "Tên công ty không được để trống." });

            business.CompanyName = dto.CompanyName.Trim();
            business.CompanyAddress = dto.CompanyAddress?.Trim();
            business.Industry = dto.Industry?.Trim();
            business.Description = dto.Description?.Trim();
            business.WebsiteUrl = dto.WebsiteUrl?.Trim();
            business.CompanySize = dto.CompanySize;
            business.TaxCode = dto.TaxCode?.Trim();
            business.FoundedYear = dto.FoundedYear;

            await _context.SaveChangesAsync();

            return Json(new { success = true, companyId = business.Id });
        }
    }
}
