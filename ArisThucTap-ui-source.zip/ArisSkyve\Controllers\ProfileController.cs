using ArisSkyve.Application.DTOs;
using ArisSkyve.Domain.Entities;
using ArisSkyve.Infrastructure.Data.Context;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace ArisSkyve.Controllers
{
    [Authorize]
    public class ProfileController : Controller
    {
        public ArisDBContext _context;
        public ProfileController(ArisDBContext dBContext) {
            _context = dBContext;
        }
        public IActionResult Index()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(userIdClaim, out int userId))
            {
                return Challenge();
            }

            var user = _context.Users
                .Include(u => u.Posts)
                .Include(u => u.Likes)
                .Include(u => u.Profile)
                    .ThenInclude(p => p.ContactMethods)
                .Include(u => u.Profile)
                    .ThenInclude(p => p.Education)
                .Include(u => u.Profile)
                    .ThenInclude(p => p.Resumes)
                        .ThenInclude(r => r.Skills)
                .FirstOrDefault(u => u.Id == userId);

            if (user == null)
            {
                return NotFound();
            }

            // Real recent jobs for recommendations sidebar
            ViewBag.RecentJobs = _context.JobPostings
                .Include(j => j.Locations)
                .Where(j => j.isActive)
                .OrderByDescending(j => j.CreatedAt)
                .Take(3)
                .ToList();

            // Calculate real profile completion readiness percentage based on documented fields
            int readiness = 0;
            if (!string.IsNullOrWhiteSpace(user.Profile?.AvatarUrl)) readiness += 20;
            if (!string.IsNullOrWhiteSpace(user.Profile?.Bio) && user.Profile.Bio != "Chưa có tiểu sử.") readiness += 20;
            if (!string.IsNullOrWhiteSpace(user.Profile?.Location) && user.Profile.Location != "Chưa cập nhật" && user.Profile.Location != "Vị trí chưa xác định") readiness += 20;
            if (user.Profile?.ContactMethods != null && user.Profile.ContactMethods.Any()) readiness += 20;
            if (user.Profile?.Resumes != null && user.Profile.Resumes.Any()) readiness += 20;

            ViewBag.ProfileReadiness = readiness;

            return View(user);
        }
        [HttpPost]
        public IActionResult AddContact(ContactMethod contact)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(userIdClaim, out int userId))
            {
                return Unauthorized();
            }

            var profile = _context.Profiles
                .Include(p => p.ContactMethods)
                .FirstOrDefault(p => p.UserId == userId);

            if (profile != null)
            {
                var newContact = new ContactMethod
                {
                    MethodType = contact.MethodType,
                    Value = contact.Value,
                    idEmployesAccount = profile.Id 
                };

                _context.ContactMethods.Add(newContact);
                _context.SaveChanges();
            }

            return RedirectToAction("Index");
        }
        [HttpPost]
        public async Task<IActionResult> UpdateBio([FromBody] UpdateBioDto dto)
        {
            var userIdStr = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (userIdStr == null)
                return Unauthorized();

            int userId = int.Parse(userIdStr);

            var user = await _context.Users
                .Include(u => u.Profile)
                .FirstOrDefaultAsync(u => u.Id == userId);

            if (user == null)
                return NotFound();

            if (user.Profile == null)
            {
                user.Profile = new EmployesAccount
                {
                    UserId = user.Id,
                    FullName = user.Username ?? "User",
                    Location = "Chưa cập nhật"
                };
            }

            user.Profile.Bio = dto.Bio?.Trim();
            await _context.SaveChangesAsync();

            return Ok(new { success = true });
        }

        [HttpPost]
        public async Task<IActionResult> UpdatePreferences([FromBody] UpdatePreferencesDto dto)
        {
            var userIdStr = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userIdStr == null) return Unauthorized();

            int userId = int.Parse(userIdStr);
            var user = await _context.Users
                .Include(u => u.Profile)
                .FirstOrDefaultAsync(u => u.Id == userId);

            if (user == null || user.Profile == null) return NotFound();

            user.Profile.IsRemoteJob = dto.IsRemoteJob;
            user.Profile.IsLookingForJob = dto.IsLookingForJob;
            await _context.SaveChangesAsync();

            return Ok(new { success = true, isRemoteJob = user.Profile.IsRemoteJob, isLookingForJob = user.Profile.IsLookingForJob });
        }
    }
}
